"""R12 targeted timings for RC1 paths no runner row isolates.

Rows, each a batch timed per sample (seconds per batch):

- ``open/close x200``: enter and exit ``async with`` on a small gzip file
  for reading, 200 times (R15 changed how close() and context exit settle
  the owned native close).
- ``open + seek_end drain x20``: open a file of about 1 MiB and seek(0, SEEK_END),
  20 times; the seek drains the whole stream through the end-relative loop
  that R04 changed.
- ``open + peek + seek_end x200``: open the 1 KiB file, peek(1025) to EOF,
  then seek(0, SEEK_END), 200 times; R04's branch that counts peeked output (b2
  skips that count, so this times the path, not equal work).
- ``text writelines empty runs x20``: write 20,000 items in text mode,
  12,000 of them empty strings in short runs, then a run of 20,000 empty strings,
  20 times (R08 stopped storing empty strings in ``pending``).

Imports aiogzip only from SOURCE_ROOT/src and verifies it, pins the engine as
the runner does (AIOGZIP_ENGINE=stdlib for stdlib; unset for zlib-ng, which
must then be active), and records the source commit and clean state.
Fixtures are seeded, so both sides read the same bytes.

    rc1_paths.py --source-root ROOT --engine {stdlib,zlib-ng} --repeat N --output OUT
"""

import argparse
import asyncio
import gzip
import hashlib
import json
import os
import random
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path

BATCH = 200


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--engine", choices=("stdlib", "zlib-ng"), required=True)
    parser.add_argument("--repeat", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.repeat < 5 or args.repeat % 2 == 0:
        sys.exit("--repeat must be odd and at least 5")
    root = args.source_root.resolve()
    if args.engine == "stdlib":
        os.environ["AIOGZIP_ENGINE"] = "stdlib"
    else:
        os.environ.pop("AIOGZIP_ENGINE", None)
    sys.path.insert(0, str(root / "src"))
    import aiogzip

    imported = Path(aiogzip.__file__).resolve()
    if not imported.is_relative_to(root / "src"):
        sys.exit(f"imported {imported}, not from {root}")
    engines = aiogzip.engine_info().__dict__
    want = "zlib-ng" if args.engine == "zlib-ng" else "stdlib-zlib"
    if engines["decompression"] != want:
        sys.exit(f"decompression engine {engines['decompression']!r}, expected {want!r}")

    def git(*a):
        return subprocess.run(
            ["git", "-C", str(root), *a], check=True, capture_output=True, text=True
        ).stdout.strip()

    rng = random.Random(0)
    small = gzip.compress(rng.randbytes(1024), mtime=0)
    large = gzip.compress(
        b"".join(rng.choice((b"alpha ", b"beta ", b"gamma\n")) for _ in range(180_000))[
            : 1 << 20
        ],
        mtime=0,
    )
    with tempfile.TemporaryDirectory(prefix="aiogzip-r12-") as tmp:
        small_path = Path(tmp) / "small.gz"
        large_path = Path(tmp) / "large.gz"
        small_path.write_bytes(small)
        large_path.write_bytes(large)

        async def open_close():
            for _ in range(BATCH):
                async with aiogzip.AsyncGzipBinaryFile(small_path, "rb"):
                    pass

        async def seek_end_drain():
            for _ in range(20):
                async with aiogzip.AsyncGzipBinaryFile(large_path, "rb") as f:
                    if await f.seek(0, os.SEEK_END) <= 0:
                        raise AssertionError("seek_end did not drain")

        async def peek_seek_end():
            for _ in range(BATCH):
                async with aiogzip.AsyncGzipBinaryFile(small_path, "rb") as f:
                    await f.peek(1025)  # past the 1 KiB payload: reaches EOF
                    await f.seek(0, os.SEEK_END)

        items = ["line\n", "", "", "x", ""] * 4000 + [""] * 20000
        out_path = Path(tmp) / "out.gz"

        async def writelines_empty():
            for _ in range(20):
                async with aiogzip.AsyncGzipTextFile(out_path, "wt") as f:
                    await f.writelines(items)
            if gzip.decompress(out_path.read_bytes()) != b"line\nx" * 4000:
                raise AssertionError("writelines output differs")

        async def measure(operation):
            await operation()  # warm-up, not recorded
            samples = []
            for _ in range(args.repeat):
                start = time.perf_counter()
                await operation()
                samples.append(time.perf_counter() - start)
            return samples

        rows = []
        for name, operation in (
            (f"open/close x{BATCH}", open_close),
            ("open + seek_end drain x20", seek_end_drain),
            (f"open + peek + seek_end x{BATCH}", peek_seek_end),
            ("text writelines empty runs x20", writelines_empty),
        ):
            samples = asyncio.run(measure(operation))
            rows.append(
                {
                    "name": name,
                    "status": "ok",
                    "sample_count": len(samples),
                    "samples": samples,
                    "median_seconds": statistics.median(samples),
                    "minimum_seconds": min(samples),
                }
            )
    record = {
        "script": "rc1_paths.py",
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "source": {
            "root": str(root),
            "commit": git("rev-parse", "HEAD"),
            "dirty": bool(git("status", "--porcelain")),
            "imported": str(imported),
        },
        "engine": {"requested": args.engine, "active": engines},
        "fixtures": {
            "small_sha256": hashlib.sha256(small).hexdigest(),
            "large_sha256": hashlib.sha256(large).hexdigest(),
        },
        "repeat": args.repeat,
        "results": rows,
    }
    with args.output.open("x", encoding="utf-8") as output:
        json.dump(record, output, indent=2, sort_keys=True)
        output.write("\n")


if __name__ == "__main__":
    main()
