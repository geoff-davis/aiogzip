# G06 scaling

Matched sizes and capture positions only. Ratios describe measured sizes, not a universal complexity proof. No exclusion of noisy complete blocks; input dispositions retained. No gate closure.

| Source | Family | Sizes | Median doubling ratio | Input dispositions |
| --- | --- | --- | ---: | --- |
