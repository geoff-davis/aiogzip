import hashlib
import json
from pathlib import Path
from statistics import median
p = Path(__file__).resolve().parent
captures = {(n, s): json.loads((p / f'{n}-{s}.json').read_text()) for n in range(4) for s in 'BD'}
rows = []
for i in range(16):
    reference = captures[0, 'B']['rows'][i]
    ratios = []
    counts = []
    for n in range(4):
        pair = {s: captures[n, s]['rows'][i] for s in 'BD'}
        assert all((r['fixture'], r['compress'], r['chunk_size']) == (reference['fixture'], reference['compress'], reference['chunk_size']) for r in pair.values())
        best = {s: min(b['seconds'] for b in r['batches'][2:]) for s, r in pair.items()}
        ratios.append(best['D'] / best['B'])
        counts.append({s: r['counts'] for s, r in pair.items()})
        assert pair['B']['counts'] == pair['D']['counts']
    rows.append(dict(fixture=reference['fixture'],compress=reference['compress'],chunk_size=reference['chunk_size'],ratios=ratios,median_ratio=median(ratios),counts=counts))
summary = dict(rows=rows,limitations='Exploratory, no host screen, frozen dirty D=6f5be82+archived initial patch vs B=f73ae8d. Final None-sentinel refinement not timed. No WP4 comparison, qualification, or equivalence conclusion for mixed-sign controls.',sha256={f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*') if f.is_file() and f.name != 'summary.json'})
(p / 'summary.json').write_text(json.dumps(summary,indent=2))
for r in rows:
    values = [100*(v-1) for v in r['ratios']]
    print(r['fixture'], 'compress' if r['compress'] else 'decode', r['chunk_size'], f"median {100*(r['median_ratio']-1):+.2f}% range {min(values):+.2f}..{max(values):+.2f}%")
