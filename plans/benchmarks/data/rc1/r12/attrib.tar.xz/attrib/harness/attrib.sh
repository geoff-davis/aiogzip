#!/usr/bin/env bash
# R12 investigation: attribute the inspect()/verify() small-file cost.
# Six rounds; in each, every (engine, fixture) runs all six variants in that
# round's row of a 6x6 Williams square (each variant once per position, each
# ordered neighbour pair once), one fresh process per variant, on CPU 13.
# Launched as its own transient systemd service, so the quiet gate and monitor
# subtract exactly this run's cgroup.
set -euo pipefail
REPO=/home/geoff/Projects/personal/aiogzip
BENCH=$REPO/.cache/rc1-bench
PY=$REPO/.venv/bin/python
CPU=13
A=/tmp/aiogzip-r12x-b2
B=/tmp/aiogzip-r12x-cand
[ -n "${INVOCATION_ID:-}" ] || { echo "run under systemd-run"; exit 1; }
cd "$BENCH"
sha256sum --check --strict --quiet attrib.sha256 || { echo "harness hash mismatch"; exit 1; }
cd "$REPO"
A_SHA=$(git rev-parse 962bfe4); B_SHA=$(git rev-parse dd70af4)
OUT=$BENCH/attrib-$(date +%Y%m%d-%H%M%S)
mkdir -p "$OUT"
for w in "$A" "$B"; do
  if [ -e "$w" ]; then git worktree remove --force "$w"; fi
done
git worktree prune
git worktree add -q --detach "$A" "$A_SHA"
git worktree add -q --detach "$B" "$B_SHA"
for pair in "$A $A_SHA" "$B $B_SHA"; do
  set -- $pair
  [ "$(git -C "$1" rev-parse HEAD)" = "$2" ] || { echo "commit mismatch $1"; exit 1; }
  [ -z "$(git -C "$1" status --porcelain)" ] || { echo "dirty $1"; exit 1; }
done
ENV_FP=18d9286b76b256346dd61f51f3ccbf7bf78b788ccd17c07ccdff4fc93543d187
[ "$("$PY" "$BENCH/envcheck.py" "$OUT/environment.json")" = "$ENV_FP" ] || { echo "environment fingerprint mismatch"; exit 1; }
{
  echo "a $A_SHA"; echo "b $B_SHA"; date; uptime; cat /proc/self/cgroup
  sha256sum "$BENCH/attrib.sh" "$BENCH/attrib.sha256"; cat "$BENCH/attrib.sha256"
} > "$OUT/provenance.txt"

if ! "$PY" "$BENCH/quiet_gate.py" gate > "$OUT/quiet-gate.log" 2>&1; then
  echo "deferred: see $OUT/quiet-gate.log"; exit 0
fi
"$PY" "$BENCH/quiet_gate.py" monitor > "$OUT/foreign.log" 2>&1 &
MONITOR=$!
trap 'kill "$MONITOR" 2>/dev/null || true' EXIT

VARIANTS=(b2 full no_open no_read no_close none)
WILLIAMS=(0 1 5 2 4 3)  # first row; row r adds r - 1 (mod 6)
printf 'round\tengine\tfixture\tvariant\tstart\tend\n' > "$OUT/runs.tsv"
for round in 1 2 3 4 5 6; do
  for engine in stdlib zlib-ng; do
    for fixture in incompressible compressible; do
      for i in 0 1 2 3 4 5; do
        v=${VARIANTS[$(( (WILLIAMS[i] + round - 1) % 6 ))]}
        root=$B; [ "$v" = b2 ] && root=$A
        start=$(date +%s.%N)
        taskset -c "$CPU" "$PY" "$BENCH/attrib.py" --source-root "$root" \
          --variant "$v" --fixture "$fixture" --engine "$engine" \
          --output "$OUT/$round-$engine-$fixture-$v.json" < /dev/null
        printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$round" "$engine" "$fixture" "$v" "$start" "$(date +%s.%N)" >> "$OUT/runs.tsv"
      done
    done
  done
  echo "round $round done $(date +%T)"
done
sleep 6
echo "results in $OUT"
