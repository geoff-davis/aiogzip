#!/usr/bin/env bash
# WP8 benchmark window (method A): C0 vs candidate, both engines, ABBA ABBA.
set -euo pipefail
REPO=/home/geoff/Projects/personal/aiogzip
BENCH=$REPO/.cache/wp8-bench
OUT=$BENCH/results-$(date +%Y%m%d-%H%M%S)
C0=/tmp/aiogzip-wp8-c0
CAND=/tmp/aiogzip-wp8-cand
C0_SHA=b074bdc77e45e9033769fb96a999e98e8931c24b
CAND_SHA=${CAND_SHA:?set CAND_SHA}
UV=/home/geoff/.local/bin/uv
PY=$REPO/.venv/bin/python
mkdir -p "$OUT"
cd "$REPO"

if ! "$PY" "$BENCH/quiet_gate.py" gate > "$OUT/quiet-gate.log" 2>&1; then
  echo "deferred: see $OUT/quiet-gate.log"
  exit 0
fi

# Fresh worktrees at the exact pinned commits; never reuse a stale directory.
for w in "$C0" "$CAND"; do
  if [ -e "$w" ]; then git worktree remove --force "$w"; fi
done
git worktree prune
git worktree add -q --detach "$C0" "$C0_SHA"
git worktree add -q --detach "$CAND" "$CAND_SHA"
[ "$(git -C "$C0" rev-parse HEAD)" = "$C0_SHA" ] || { echo "C0 commit mismatch"; exit 1; }
[ "$(git -C "$CAND" rev-parse HEAD)" = "$CAND_SHA" ] || { echo "candidate commit mismatch"; exit 1; }
for w in "$C0" "$CAND"; do
  [ -z "$(git -C "$w" status --porcelain)" ] || { echo "dirty $w"; exit 1; }
done
# The shared venv must match the pinned candidate lock.
[ "$(sha256sum < uv.lock)" = "$(sha256sum < "$CAND/uv.lock")" ] || { echo "main uv.lock differs from candidate"; exit 1; }

{
  date; uptime
  echo "c0 $C0_SHA"; echo "candidate $CAND_SHA"
  echo "uv.lock $(sha256sum < uv.lock)"
  sha256sum "$BENCH/run.sh" "$BENCH/quiet_gate.py" "$BENCH/summarize.py"
} > "$OUT/provenance.txt"

"$PY" "$BENCH/quiet_gate.py" monitor > "$OUT/foreign.log" 2>&1 &
MONITOR=$!
trap 'kill "$MONITOR" 2>/dev/null || true' EXIT

printf 'engine\tn\tside\tstart\tend\n' > "$OUT/captures.tsv"
for engine in stdlib zlib-ng; do
  n=0
  for side in A B B A A B B A; do
    n=$((n+1))
    root=$C0; [ "$side" = B ] && root=$CAND
    start=$(date +%s.%N)
    taskset -c 13 "$UV" run --frozen python "$CAND/benchmarks/run_benchmarks.py" \
      --category io,micro,text_origin,read_health --repeat 5 --engine "$engine" \
      --source-root "$root" --output "$OUT/$engine-$n-$side.json" \
      > "$OUT/$engine-$n-$side.log" 2>&1
    printf '%s\t%s\t%s\t%s\t%s\n' "$engine" "$n" "$side" "$start" "$(date +%s.%N)" >> "$OUT/captures.tsv"
    echo "$engine $n $side done $(date +%T)"
  done
done
sleep 6  # one more monitor sample after the last capture
echo "results in $OUT"
