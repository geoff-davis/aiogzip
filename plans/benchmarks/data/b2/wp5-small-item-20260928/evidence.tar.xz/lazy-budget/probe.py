import argparse
import asyncio
import gzip
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
SETUP = ROOT / '.cache/wp5-qualification-onecore'
OUT = Path(__file__).resolve().parent

async def measure(variant):
    os.environ['AIOGZIP_ENGINE'] = 'stdlib'
    source = ROOT if variant == 'D' else SETUP / 'candidate'
    sys.path.insert(0, str(source / 'src'))
    sys.path.insert(0, str(SETUP / 'harness/scripts'))
    import aiogzip
    import aiogzip._streaming as stream
    import aiogzip._codec_async as driver
    from measure_b2_stream_fairness import sample, throughput_batch
    assert Path(aiogzip.__file__).resolve().is_relative_to(source.resolve())
    if variant == 'C':
        stream._SOURCE_ITEMS_CHECKPOINT = 1 << 60
    results = []
    for fixture, compress in [('text', True), ('random', True), ('random', False)]:
        size = 4 * 1024 * 1024
        line = b'{"id":123,"message":"representative repeated JSONL text","ok":true}\n'
        payload = random.Random(20260927).randbytes(size) if fixture == 'random' else (line * (size // len(line) + 1))[:size]
        data = payload if compress else gzip.compress(payload, mtime=0)
        items = [data[i:i+64] for i in range(0,len(data),64)]
        kw = dict(compress=compress, fast=False)
        await throughput_batch(aiogzip,items,payload,**kw,target_seconds=.4,min_operations=3)
        batches = [await throughput_batch(aiogzip,items,payload,**kw,target_seconds=.1,min_operations=3) for _ in range(7)]
        counts = dict(source=0, codec=0)
        orig_s, orig_d = stream._cooperative_checkpoint, driver._cooperative_checkpoint
        async def cs():
            counts['source'] += 1
            await orig_s()
        async def cd():
            counts['codec'] += 1
            await orig_d()
        stream._cooperative_checkpoint, driver._cooperative_checkpoint = cs, cd
        try:
            counted = await sample(aiogzip,items,payload,**kw,ticker=False)
        finally:
            stream._cooperative_checkpoint, driver._cooperative_checkpoint = orig_s, orig_d
        results.append(dict(fixture=fixture,compress=compress,items=len(items),batches=batches,counts=counts,counted=counted))
    return dict(variant=variant,source=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),dirty=subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True),import_path=aiogzip.__file__,engine=aiogzip.engine_info(),python=sys.version,affinity=sorted(os.sched_getaffinity(0)),rows=results)

if __name__ == '__main__':
    if len(sys.argv)>1:
        print(json.dumps(asyncio.run(measure(sys.argv[1])),default=str))
    else:
        manifest=dict(start=time.time(),probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),orders=['BD','DB','BD','DB'],limitations='Exploratory diagnostic, not qualification. D is explicitly dirty working source: lazy budget loading; B is frozen WP5. Exploratory only. Counts instrumented separately after timing. First two batches discarded prospectively; retain five. No ticker in timings.')
        (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
        for n,order in enumerate(manifest['orders']):
            for variant in order:
                start=time.time()
                p=subprocess.run(['taskset','-c','13',str(SETUP/'venv/bin/python'),str(Path(__file__).resolve()),variant],capture_output=True,text=True,check=True)
                result=json.loads(p.stdout)
                result.update(start=start,end=time.time(),load=os.getloadavg())
                (OUT/f'{n}-{variant}.json').write_text(json.dumps(result,indent=2))
                print(n,variant,'done',flush=True)
