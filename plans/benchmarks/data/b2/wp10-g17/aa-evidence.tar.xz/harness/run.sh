#!/usr/bin/env bash
# G17 benchmark windows (method A), both engines, ABBA ABBA.
#   MODE=aa   C0 (A) against C0 (B): the noise control
#   MODE=c0   C0 (A) against the final candidate (B): the state-refactor effect
#   MODE=wp0  WP0 baseline dc8950c (A) against the final candidate (B): cumulative
# Every input comes from manifest-$MODE.json, whose hash, like every other
# harness file's, is pinned in harness.sha256; the systemd unit pins the
# hashes of this script and of harness.sha256. Nothing else is configurable.
# Each capture runs the runner categories, then the write sizes. After the
# ABBA loop, MODE=c0 and MODE=wp0 run structural-$MODE.txt.
set -euo pipefail
REPO=/home/geoff/Projects/personal/aiogzip
BENCH=$REPO/.cache/wp10-bench
MODE=${MODE:?set MODE to aa, c0 or wp0}
case "$MODE" in aa|c0|wp0) ;; *) echo "unknown MODE $MODE"; exit 1 ;; esac
PY=$REPO/.venv/bin/python
UV=/home/geoff/.local/bin/uv
CPU=13
A=/tmp/aiogzip-g17-a
B=/tmp/aiogzip-g17-b
RUNNER=/tmp/aiogzip-g17-runner
cd "$BENCH"
sha256sum --check --strict --quiet harness.sha256 || { echo "harness hash mismatch"; exit 1; }
MANIFEST=$BENCH/manifest-$MODE.json
field() { "$PY" -c 'import json,sys; v=json.load(open(sys.argv[1]))[sys.argv[2]]; print("" if v is None else v)' "$MANIFEST" "$1"; }
[ "$(field mode)" = "$MODE" ] || { echo "manifest mode mismatch"; exit 1; }
A_SHA=$(field a); B_SHA=$(field b); RUNNER_SHA=$(field runner)
CATEGORIES=$(field categories)
cd "$REPO"

OUT=$BENCH/results-$MODE-$(date +%Y%m%d-%H%M%S)
mkdir -p "$OUT"
cp "$MANIFEST" "$OUT/window.json"

# Fresh worktrees at the exact pinned commits; never reuse a stale directory.
# A and B are separate worktrees even when they share a commit (MODE=aa).
for w in "$A" "$B" "$RUNNER"; do
  if [ -e "$w" ]; then git worktree remove --force "$w"; fi
done
git worktree prune
git worktree add -q --detach "$A" "$A_SHA"
git worktree add -q --detach "$B" "$B_SHA"
git worktree add -q --detach "$RUNNER" "$RUNNER_SHA"
for pair in "$A:$A_SHA" "$B:$B_SHA" "$RUNNER:$RUNNER_SHA"; do
  w=${pair%%:*}; sha=${pair#*:}
  [ "$(git -C "$w" rev-parse HEAD)" = "$sha" ] || { echo "commit mismatch $w"; exit 1; }
  [ -z "$(git -C "$w" status --porcelain)" ] || { echo "dirty $w"; exit 1; }
done
[ "$(git rev-parse "$RUNNER_SHA:benchmarks")" = "$(field runner_benchmarks_tree)" ] || { echo "runner benchmarks tree mismatch"; exit 1; }
[ "$(git rev-parse "$RUNNER_SHA:scripts")" = "$(field runner_scripts_tree)" ] || { echo "runner scripts tree mismatch"; exit 1; }
[ "$(sha256sum < "$RUNNER/uv.lock" | cut -c1-64)" = "$(field uv_lock_sha256)" ] || { echo "runner uv.lock mismatch"; exit 1; }
[ "$(sha256sum < uv.lock | cut -c1-64)" = "$(field uv_lock_sha256)" ] || { echo "main uv.lock mismatch"; exit 1; }
# The shared venv must be in sync with that lock and match the pinned
# installed-environment fingerprint.
"$UV" sync --locked --all-extras --check > "$OUT/uv-sync-check.log" 2>&1 || { echo "venv not in sync with uv.lock"; exit 1; }
[ "$("$PY" "$BENCH/envcheck.py" "$OUT/environment.json")" = "$(field env_fingerprint)" ] || { echo "environment fingerprint mismatch"; exit 1; }

if ! "$PY" "$BENCH/quiet_gate.py" gate > "$OUT/quiet-gate.log" 2>&1; then
  echo "deferred: see $OUT/quiet-gate.log"
  exit 0
fi

{
  date; uptime
  cat "$BENCH/harness.sha256"
  sha256sum "$BENCH/run.sh" "$BENCH/harness.sha256"
} > "$OUT/provenance.txt"

"$PY" "$BENCH/quiet_gate.py" monitor > "$OUT/foreign.log" 2>&1 &
MONITOR=$!
trap 'kill "$MONITOR" 2>/dev/null || true' EXIT

printf 'engine\tn\tside\tstep\tstart\tend\n' > "$OUT/captures.tsv"
record() {  # engine n side step start
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$1" "$2" "$3" "$4" "$5" "$(date +%s.%N)" >> "$OUT/captures.tsv"
}

for engine in stdlib zlib-ng; do
  n=0
  for side in A B B A A B B A; do
    n=$((n+1))
    root=$A; [ "$side" = B ] && root=$B
    start=$(date +%s.%N)
    taskset -c "$CPU" "$PY" "$RUNNER/benchmarks/run_benchmarks.py" \
      --category "$CATEGORIES" --repeat 5 \
      --regression-profile quick --regression-mode throughput \
      --engine "$engine" --source-root "$root" \
      --output "$OUT/$engine-$n-$side.json" < /dev/null > "$OUT/$engine-$n-$side.log" 2>&1
    record "$engine" "$n" "$side" runner "$start"
    start=$(date +%s.%N)
    taskset -c "$CPU" "$PY" "$RUNNER/benchmarks/bench_a3_regressions.py" \
      --categories writes --repeat 5 \
      --engine "$engine" --source-root "$root" \
      --output "$OUT/$engine-$n-$side-writes.json" < /dev/null > "$OUT/$engine-$n-$side-writes.log" 2>&1
    record "$engine" "$n" "$side" writes "$start"
    echo "$engine $n $side done $(date +%T)"
  done
done

if [ "$MODE" != aa ]; then
  # Structural and resource gates: each step once per side and engine, A then
  # B on stdlib and B then A on zlib-ng.
  mkdir -p "$OUT/structural"
  steps_file=$BENCH/structural-$MODE.txt
  cp "$steps_file" "$OUT/structural/steps.txt"
  for engine in stdlib zlib-ng; do
    order="A B"; [ "$engine" = zlib-ng ] && order="B A"
    while IFS='|' read -r label engines script args; do
      if [ -z "$label" ] || [ "${label#\#}" != "$label" ]; then continue; fi
      case " $engines " in *" $engine "*) ;; *) continue ;; esac
      for side in $order; do
        root=$A; [ "$side" = B ] && root=$B
        engine_args=(--engine "$engine")
        [ "$script" = measure_b2_partial_read.py ] && engine_args=()
        start=$(date +%s.%N)
        # shellcheck disable=SC2086
        taskset -c "$CPU" "$PY" "$RUNNER/scripts/$script" \
          --source-root "$root" "${engine_args[@]}" $args \
          --output "$OUT/structural/$label-$engine-$side.json" \
          < /dev/null > "$OUT/structural/$label-$engine-$side.log" 2>&1
        record "$engine" "$label" "$side" structural "$start"
        echo "$label $engine $side done $(date +%T)"
      done
    done < "$steps_file"
  done
fi
sleep 6  # one more monitor sample after the last capture
echo "results in $OUT"
