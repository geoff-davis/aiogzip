"""R12 re-check: time aiogzip.verify for b2, the candidate and the read fix.

One process times one variant of ``aiogzip.verify`` on one fixture, so every
variant starts from the same fresh interpreter. Variants:

  b2        the baseline source (no patching)
  full      the candidate source as built
  no_open   candidate, path open via plain aiofiles.open (no _acquire_path)
  no_read   candidate, reads via source.read (no _initial_call settling)
  no_close  candidate, close via source.close (no _initial_call settling)
  none      candidate with all three reverted
  fix       the R12 follow-up source as built (no patching)

The patches change only how _scan_gzip reaches the native source, never what
it reads. Before timing, one untimed call must return the expected
VerificationResult (one member, the fixture's compressed size, 1 MiB out).
"""

import argparse
import asyncio
import gzip
import hashlib
import json
import os
import random
import statistics
import sys
import tempfile
import time

VARIANTS = ("b2", "full", "no_open", "no_read", "no_close", "none", "fix")
FIXTURES = ("incompressible", "compressible")


def fixture(name: str) -> bytes:
    if name == "incompressible":
        payload = random.Random(0).randbytes(1024 * 1024)
    else:
        payload = b"A" * (1024 * 1024)
    return gzip.compress(payload, mtime=0)


def patch(variant: str) -> None:
    import aiofiles

    from aiogzip import _inspection

    if variant in ("no_open", "none"):

        async def plain_open(filename, mode, opener):
            return await aiofiles.open(filename, mode)

        _inspection._acquire_path = plain_open
    native = _inspection._is_native_source
    skip = {"no_read": {"read"}, "no_close": {"close"}, "none": {"read", "close"}}
    skipped = skip.get(variant, set())
    if skipped:
        _inspection._is_native_source = lambda source, method: (
            method not in skipped and native(source, method)
        )


async def run(path: str, calls: int, batches: int) -> tuple[list[float], object]:
    import aiogzip

    result = await aiogzip.verify(path)  # untimed result check, before timing
    want = (1, os.path.getsize(path), 1024 * 1024)
    got = (result.member_count, result.compressed_size, result.uncompressed_size)
    if got != want:
        raise SystemExit(f"verify returned {got}, expected {want}")
    for _ in range(calls):  # warm-up batch
        await aiogzip.verify(path)
    per_call = []
    for _ in range(batches):
        start = time.perf_counter()
        for _ in range(calls):
            await aiogzip.verify(path)
        per_call.append((time.perf_counter() - start) / calls)
    return per_call, result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--variant", choices=VARIANTS, required=True)
    parser.add_argument("--fixture", choices=FIXTURES, required=True)
    parser.add_argument("--engine", choices=("stdlib", "zlib-ng"), required=True)
    parser.add_argument("--calls", type=int, default=200)
    parser.add_argument("--batches", type=int, default=5)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    if args.engine == "stdlib":
        os.environ["AIOGZIP_ENGINE"] = "stdlib"
    else:
        os.environ.pop("AIOGZIP_ENGINE", None)
    sys.path.insert(0, os.path.join(args.source_root, "src"))
    import aiogzip

    expected = os.path.realpath(os.path.join(args.source_root, "src", "aiogzip"))
    if os.path.dirname(os.path.realpath(aiogzip.__file__)) != expected:
        raise SystemExit(f"imported {aiogzip.__file__}, expected {expected}")
    info = aiogzip.engine_info().__dict__
    want = "zlib-ng" if args.engine == "zlib-ng" else "stdlib-zlib"
    if info["decompression"] != want:
        raise SystemExit(f"decompression engine {info['decompression']!r}, expected {want!r}")

    if args.variant not in ("b2", "fix"):
        patch(args.variant)

    data = fixture(args.fixture)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, f"{args.fixture}.gz")
        with open(path, "wb") as handle:
            handle.write(data)
        per_call, result = asyncio.run(run(path, args.calls, args.batches))

    with open(__file__, "rb") as handle:
        own = hashlib.sha256(handle.read()).hexdigest()
    record = {
        "variant": args.variant,
        "fixture": args.fixture,
        "engine": args.engine,
        "engine_info": info,
        "source_root": args.source_root,
        "aiogzip_file": aiogzip.__file__,
        "fixture_sha256": hashlib.sha256(data).hexdigest(),
        "result": repr(result),
        "calls": args.calls,
        "batches": args.batches,
        "per_call_s": per_call,
        "median_s": statistics.median(per_call),
        "script_sha256": own,
    }
    with open(args.output, "w") as handle:
        json.dump(record, handle, indent=2, default=str)


if __name__ == "__main__":
    main()
