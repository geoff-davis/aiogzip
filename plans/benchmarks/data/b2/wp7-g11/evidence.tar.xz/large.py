import asyncio, os, sys, tempfile, time
import aiogzip
from aiogzip import AsyncGzipTextFile
assert aiogzip.__file__.startswith(sys.argv[1]), aiogzip.__file__
n = 1024 * 1024
path = os.path.join(tempfile.mkdtemp(), "f.gz")
async def main():
    async with AsyncGzipTextFile(path, "wt") as f: await f.write("x" * n)
    ts = []
    for _ in range(60):
        t = time.perf_counter()
        async with AsyncGzipTextFile(path, "rt", chunk_size=65536) as f: await f.read(n)
        ts.append(time.perf_counter() - t)
    ts.sort(); print(" ".join(f"{v*1e3:.3f}" for v in (ts[0], ts[6], ts[30])))
asyncio.run(main())
