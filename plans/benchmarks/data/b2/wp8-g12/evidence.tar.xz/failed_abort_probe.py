"""Failed-abort probe: an abort whose active read swallows cancellation and
whose underlying close fails. Run with PYTHONPATH=<root>/src, passing <root>/src."""
import asyncio, gzip, sys
import aiogzip
from aiogzip import AsyncGzipTextFile
assert aiogzip.__file__.startswith(sys.argv[1])
lines = [f"line {i}\n" for i in range(3)] + ["x" * 5000 + "\n", "tail\n"]
data = gzip.compress("".join(lines).encode(), mtime=0)
class Src:
    def __init__(s):
        s.pos = 0; s.block = asyncio.Event(); s.blocking = False; s.entered = asyncio.Event()
    async def read(s, n=-1):
        if s.blocking:
            s.entered.set()
            try: await s.block.wait()
            except asyncio.CancelledError: pass  # swallow: return data anyway
        n = len(data) - s.pos if n < 0 else n
        out = data[s.pos:s.pos + n]; s.pos += len(out); return out
    def close(s): raise OSError("underlying close failed")
async def main():
    src = Src()
    f = AsyncGzipTextFile(None, "rt", fileobj=src, closefd=True, chunk_size=16)
    try:
        async with f:
            print("first", repr(await f.readline()))
            src.blocking = True
            task = asyncio.create_task(f.read())
            await src.entered.wait()
            raise RuntimeError("body")
    except RuntimeError as e:
        print("body error preserved:", e)
    r = await asyncio.gather(task, return_exceptions=True)
    print("task:", type(r[0]).__name__, str(r[0])[:70])
    bf = f._binary_file
    # C0 exposes _read_broken/_read_poisoned; WP8 has _read_is_healthy()/_read_poison_seen.
    broken = bf._read_broken if hasattr(bf, "_read_broken") else not bf._read_is_healthy()
    latch = getattr(f, "_read_poisoned", None)
    latch = f._read_poison_seen if latch is None else latch
    print("closed", f.closed, "broken", broken, "latch", latch, "buffered", f._buffered_text_len())
    for _ in range(3):
        try: print("after:", repr((await f.readline())[:20]))
        except Exception as e: print("after raises:", type(e).__name__, str(e)[:70]); break
asyncio.run(main())
