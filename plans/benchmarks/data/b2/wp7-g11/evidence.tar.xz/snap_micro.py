import timeit
from aiogzip._text import _TextBufferOrigin as O
class H:
    __slots__=("_text_buffer","_text_buffer_offset","_buffer_origin","a","b","c","d","e")
h=H(); h._text_buffer="x"*100; h._text_buffer_offset=3
h._buffer_origin=O(10,(b"",0),False,0,5)
h.a,h.b,h.c,h.d,h.e=10,(b"",0),False,0,5
def c0(): return (h._text_buffer,h._text_buffer_offset,h.a,h.b,h.c,h.d,h.e)
def wp7(): return (h._text_buffer,h._text_buffer_offset,h._buffer_origin.snapshot())
def flat():
    o=h._buffer_origin
    return (h._text_buffer,h._text_buffer_offset,(o.byte_offset,o.decoder_state,o.trailing_cr,o.seen_newline_types,o.chars_to_skip))
def flat7():
    o=h._buffer_origin
    return (h._text_buffer,h._text_buffer_offset,o.byte_offset,o.decoder_state,o.trailing_cr,o.seen_newline_types,o.chars_to_skip)
for f in (c0,wp7,flat,flat7):
    t=min(timeit.repeat(f,number=200000,repeat=15))/200000
    print(f"{f.__name__:6s} {t*1e9:6.1f} ns")
