"""Exploratory: time the G06 fixture's async-for read for one source root."""
import asyncio, os, statistics, sys, time
root, engine, newline, reps = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
size = int(sys.argv[5]) if len(sys.argv) > 5 else 16 * 1024 * 1024
encoding = sys.argv[6] if len(sys.argv) > 6 else "iso2022_jp"
newline = {"None": None, "empty": "", "lf": "\n", "cr": "\r", "crlf": "\r\n"}[newline]
os.environ["AIOGZIP_ENGINE"] = engine
sys.path.insert(0, os.path.join(root, "src"))
sys.path.insert(0, "/home/geoff/Projects/personal/aiogzip/.cache/wp5-qualification-onecore/harness/scripts")
import aiogzip
assert aiogzip.__file__.startswith(root), aiogzip.__file__
import measure_b2_long_lines as m
case = dict(size=size, newline=newline, encoding=encoding, chunk_size=65536,
            content="repeated", ending="absent", family="long")
wire, expected, _ = m.fixture(case)
async def main():
    await m.sample(aiogzip, case, wire, expected, "timing")
    if os.environ.get("PROFILE"):
        import cProfile, pstats
        pr = cProfile.Profile(); pr.enable()
        await m.sample(aiogzip, case, wire, expected, "timing")
        pr.disable(); pstats.Stats(pr).sort_stats("tottime").print_stats(12)
        return
    t = [(await m.sample(aiogzip, case, wire, expected, "timing"))["seconds"] for _ in range(reps)]
    print(f"{root.rsplit('-',1)[-1]} {engine} {sys.argv[3]} min={min(t)*1000:.1f}ms med={statistics.median(t)*1000:.1f}ms")
asyncio.run(main())
