# WP5 checkpoint split diagnostic — 2026-09-28

Exploratory daytime evidence, not G08/G17 qualification. No production edits.
The overnight qualification evidence remains unchanged.

`probe.py` runs clean source A (aceca4b) and B (f73ae8d), and C (B with only
_SOURCE_ITEMS_CHECKPOINT raised to 2**60 in process). Same copied Python 3.14.2
environment, stdlib engine, CPU 13, frozen harness sample implementation.
Six balanced orders ABC/CBA/BCA/ACB/CAB/BAC, fresh process per capture.
Each case warms for >=0.4 seconds/3 operations, then runs seven >=0.1-second,
>=3-operation batches. First two discarded prospectively; minimum of remaining
five batch means used. Validation occurs outside timed intervals. Counts come
from a separate instrumented operation and its timings are not analyzed.

All 18 captures completed. `summarize.py` reproduces `summary.json`, preserving
all within-round comparisons. Per-case median B/A and C/A overhead:

| 64-byte case | B/A | C/A | median B minus C |
| --- | ---: | ---: | ---: |
| text compression | +6.23% | +5.89% | -0.033 ms |
| random compression | +4.51% | +4.28% | +0.197 ms |
| random decompression | +1.79% | +2.59% | -1.756 ms |

A has zero explicit checkpoints in these fixtures. B has 256 source and zero
codec checkpoints. C has zero source checkpoints; codec checkpoints are 0, 3,
and 16 respectively. These counts hold across all six captures of each variant.

Text compression is the clearest ablation: removing all explicit checkpoints
leaves the overhead. Budget bookkeeping is therefore the next investigation
target. This experiment does not isolate individual counter accesses or prove
that yields are free. B-C varies in sign, and between-process/daytime drift
prevents a reliable yield-cost estimate. C also changes counter reset cadence
and integer magnitudes; the random cases have replacement codec checkpoints.
Only load snapshots were recorded, with no foreign-CPU screen. Do not substitute
these percentages for the overnight +5.50% qualification observation.

Keep the 256-item fairness ceiling. A future optimization should preserve all
budget/cancellation/lifecycle behavior and be requalified on clean committed
sources. G08 remains open; no new benchmark windows were scheduled.
