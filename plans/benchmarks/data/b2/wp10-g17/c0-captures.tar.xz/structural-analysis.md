# G17 structural steps: evaluation against the pre-registered criteria

Read-only analysis. Nothing was run except JSON parsing. Criteria come from
`plans/reviews/v2.0.0b2-g17-preregistration.md` § "Structural steps and their criteria".
The "policy above" in that file (§ Statistics and decision rule) is B against A **by minimum**:
≤5% no action, >5% investigate and record a disposition, >10% and attributable blocks by default.

Paths used below:
- `C/` = `/home/geoff/Projects/personal/aiogzip/.cache/wp10-bench/results-c0-20261007-034407/structural/` (A = C0 `b074bdc`, B = `f202b46`)
- `W/` = `/home/geoff/Projects/personal/aiogzip/.cache/wp10-bench/results-wp0-20261007-042119/structural/` (A = WP0 `dc8950c`, B = `f202b46`)

## Provenance checks

- All 54 structural JSONs carry the expected source SHA per side. Harness is `f202b46` with empty status on both sides. Where the files record it, source status is also empty. The `g05-pending-*` files record only `commit` and a path, not a status. Requested and active decompression engine match the file label in every file.
- All `.log` files end normally ("N rows complete" or empty). None contains `error` or `Traceback`. Every script ran to completion, so none of their correctness assertions fired.
- Order, from `captures.tsv`: stdlib ran A then B; zlib-ng ran B then A. Each side ran once (no interleaving). Peak foreign CPU during the C0 structural steps was 2.39 cores, at t=1791370823, inside stdlib `g06-longline-timing` side A. It was ≤0.93 at every other point in those steps. During the WP0 structural steps the peak was 0.67 (`foreign.log`).
- C0 `b074bdc` has no `src/` diff from `2f78925`, the G06/G07/G08 gate candidate. The A side therefore already includes every cost those gates accepted. B−A measures only post-C0 changes, which touch 4 files in `src/` (`_binary.py`, `_text.py`, `_source_io.py`, `codec.py`).

## Per-step table

| Step | Engine | Criterion (as applied) | Observed A | Observed B | Verdict |
| --- | --- | --- | --- | --- | --- |
| g02-settlement (C0 window) | stdlib | Script's cancellation and abandonment assertions pass. Latencies recorded, not gated | 10 rows; executor-step-latency median 15.05 µs; caller-cancel median 4919.50 µs | 10 rows, completed; step 17.22 µs (+14.4% med, −0.9% min); cancel 4983.46 µs (+1.3% med, +0.9% min) | PASS (correctness). Latencies REPORT-ONLY |
| g02-settlement (C0 window) | zlib-ng | same | step 16.90 µs; cancel 4891.14 µs | step 15.30 µs (−9.4% med, +0.2% min); cancel 4864.77 µs (−0.5% med) | PASS. Latencies REPORT-ONLY |
| g02-settlement (WP0 window) | stdlib | same, against WP0 | step 18.71 µs; cancel 4907.01 µs | step 17.61 µs (−5.9% med, −18.9% min); cancel 4943.97 µs (+0.8%) | PASS. REPORT-ONLY |
| g02-settlement (WP0 window) | zlib-ng | same | step 20.12 µs; cancel 4880.11 µs | step 17.46 µs (−13.2% med, −19.3% min); cancel 4892.86 µs (+0.3%) | PASS. REPORT-ONLY |
| g03-source-reads | stdlib | Output-equality assertion passes. Custom read-all cost reported against C0 | 24 rows | 24 rows completed. Custom binary random read-all +4.6% min (0.943→0.987 ms). Custom binary hex read-all +0.3%. No row >5% by min | PASS (correctness). REPORT-ONLY |
| g03-source-reads | zlib-ng | same | 24 rows | Custom binary random read-all −3.1% min. Three rows >5% by min (see below) | PASS (correctness). NEEDS-ATTENTION (report rows >5%) |
| g05-pending-scaling | stdlib | Near-linear minima, 2,048→32,768 lines | hint 1: 0.787→11.529 ms (×14.65); hint 17: ×11.72 | hint 1: 0.811→11.971 ms (×14.76; doublings 1.924/1.943/1.971/2.003); hint 17: ×11.64 (1.715–1.956) | PASS |
| g05-pending-scaling | zlib-ng | same | hint 1: ×14.62; hint 17: ×11.97 | hint 1: 0.803→11.820 ms (×14.73; doublings 1.910–1.994); hint 17: ×11.96 (1.716–1.993) | PASS |
| g05-pending-bulk (default, 4m-varied, 4m-repetitive) | stdlib | Bulk rows against C0 under the policy, by min | 12 rows | Worst +2.53% (4m-repetitive `readlines(8192)`, 129.171→132.441 ms). None >5% | PASS |
| g05-pending-bulk (same three) | zlib-ng | same | 12 rows | 4m-repetitive `readlines(8192)` **+7.68%** min (107.480→115.730 ms), +8.04% med. All others between −2.29% and +2.62% | NEEDS-ATTENTION (>5%, investigation and disposition required) |
| g05-scaling (WP0 window) | stdlib | No gate criterion. `append_calls`, `growing_buffer_characters` and `peak_python_bytes` against WP0 as evidence of linear work | Generic (`""`, `"\r\n"`) work quadratic: UTF-8 gbc 8,912,896→2,155,872,256 (doublings 3.882–3.984); ISO-2022-JP 18,350,016→4,320,132,096 (3.829–3.977) | gbc = logical characters (1,048,576→16,777,216), every doubling 2.000. append_calls unchanged (16…256 / 33…513). 16 Mi generic peak 33,602,526 (UTF-8) and 69,471,390 (ISO), vs 50,300,838 and 102,860,785 in A. Fast paths have 0 work on both sides | PASS (REPORT-ONLY gate; linear work shown) |
| g05-scaling (WP0 window) | zlib-ng | same | identical work values to stdlib A | identical to stdlib B | PASS (REPORT-ONLY) |
| g05-scaling (C0 window) | both | Not in the WP0-only criterion; reported | gbc doublings 2.000 | gbc doublings 2.000. A and B work identical | REPORT-ONLY (no change) |
| g06-longline-resources | stdlib | Candidate work ratio 2.000 | gbc doublings 2.000 (n=24); append doublings 1.9697–2.000 | gbc doublings **2.000 for all 24 pairs**; append 1.9697–2.000; gbc equals returned characters on every row with work. Work identical to A on 175/175 rows. Peak B−A between 0 and +104 bytes | PASS |
| g06-longline-resources | zlib-ng | same | same | same (2.000 on 24/24; 175/175 rows identical to A) | PASS |
| g06-longline-timing | stdlib | 8→16 MiB doubling ratios against the G06 disposition (2.04–2.66; >2.5 and ISO-2022-JP rows accepted) | generic min-ratio 2.044–2.427 | generic 2.040–2.440 (min), 2.042–2.452 (med). All 15 families 2.040–2.440 | PASS |
| g06-longline-timing | zlib-ng | same | generic 2.060–2.732 (ISO-2022-JP generic 2.667 and 2.732) | generic 2.043–2.759 (min), 2.025–2.787 (med). Non-ISO generic 2.043–2.407. ISO generic 2.747 (`""`) and 2.759 (`"\r\n"`) | PASS with note: the only rows above 2.66 are ISO-2022-JP (>2.5), the class the disposition accepts. C0 shows the same excess. All rows are far below the quadratic baseline (3.69–4.97) |
| g07-read-resources | stdlib | Eager drain retained. `total_inflated_bytes` and `tracemalloc_peak_bytes` against C0 | 104 rows | `inflation` dict identical on 104/104 rows. Peak delta −56 to +200 bytes (max |Δ| 0.006%). Handle outcomes and retained-state fields identical | PASS |
| g07-read-resources | zlib-ng | same | 104 rows | same: inflation identical on 104/104; peak −56 to +200 bytes | PASS |
| g07-read-latency | stdlib | No group with zero ticks; no cohort max/min above 1.5; expected error outcomes preserved | 0 zero-tick groups (ticks 3–35); outcomes 230 output, 6 OSError, 6 BadGzipFile | 0 zero-tick groups (ticks 3–35); same outcomes, handle by handle, as A and as batch 1. Cohort A/B max/min worst 1.110 | PASS (interpretation below) |
| g07-read-latency | zlib-ng | same | 0 zero-tick; same outcomes | 0 zero-tick (3–35); outcomes identical. Cohort A/B max/min worst 1.181 | PASS (interpretation below) |
| g07-partial-read (WP0 window) | stdlib | Diagnostic. `retained_plaintext` and `tracemalloc_peak` reported | repeated-x 16,777,215 / 33,607,726; random 262,053 / 1,353,339 | repeated-x 16,777,215 / 33,607,726; random 262,053 / 1,353,355 | REPORT-ONLY (unchanged; A reproduces the WP0 record) |
| g07-partial-read (C0 window) | stdlib | same | 16,777,215 / 33,607,726; 262,053 / 1,353,355 | identical | REPORT-ONLY |
| g08-fairness-throughput | stdlib | Against C0 under the policy, by min; accepted costs cited | 16 rows | −2.90% to +0.76%. None >5% | PASS |
| g08-fairness-throughput | zlib-ng | same | 16 rows | −2.29% to +2.29% (worst: 4 KiB random decompress). None >5% | PASS |
| g08-fairness-latency | stdlib | Sibling progress; item gaps ≤256 (≤8 for empty members) | — | empty/tiny/empty-members: `ticks_before_final_item` 1–2,500 (>0 in all 7 samples); `max_items_between_ticks` 256, and 8 for empty-members. A identical | PASS |
| g08-fairness-latency | zlib-ng | same | — | same: before-final >0; max items 256, and 8 for empty-members. A identical | PASS |

Details by step follow.

### g02-settlement
Fields: `rows[*].case`, `seconds`, `median_seconds`. A finished run shows that these checks passed: `OneStep.close` raises if a completed operation is abandoned, and the cancel probe raises "cancellation was lost" (`scripts/measure_b2_native_settlement.py` lines 84 and 130). All four files per window have 10 rows of 7 samples, and the fixtures match A/B.

Decode rows, not gated:
- zlib-ng decode 1 MiB: C0 window +71.7% median, +12.2% min. B samples [146, 190, 241, 233, 175, 243, 231] µs against A [163, 138, …, 132] µs.
- zlib-ng decode 4 MiB: WP0 window +75.3% median, +15.7% min.
- The stdlib A side (which ran first) is slower on decode in the same way: C0 window 4 MiB −34.5% median for B.

Whichever side runs first looks noisier. WP1 recorded the same instability in these rows and called it inconclusive.

Files: `C/g02-settlement-{stdlib,zlib-ng}-{A,B}.json`, `W/g02-settlement-…`.

### g03-source-reads
`rows[*].minimum_seconds` and `median_seconds`, matched on (source_kind, text, surface, family, fixture_sha256).

**Correctness:** the run completed, so its output-equality assertion passed.

**Rows >5% by min, all zlib-ng (`C/g03-source-reads-zlib-ng-{A,B}.json`):**

| Row | Min, ms | Min Δ | Median Δ | Sample shape |
| --- | --- | ---: | ---: | --- |
| `rows[19]` custom binary read-sized, random | 0.611→0.706 | **+15.7%** | +15.8% | Every B sample is about 0.71–0.75 ms; A is about 0.61–0.63 ms. A consistent shift |
| `rows[21]` custom text read-all, random | 4.826→5.271 | +9.2% | +18.1% | B is bimodal, alternating about 5.27 and 5.9 ms; A is tight at about 4.83–4.91 ms |
| `rows[12]` native binary read-all, random | 0.973→1.029 | +5.7% | +9.5% | |

None exceeds 5% on stdlib. The other zlib-ng rows lie between −3.5% and +3.0%.

The custom binary read-all row that G03 deferred is +4.6% (stdlib) and −3.1% (zlib-ng).

The 4 KiB small-chunk cost that G03 deferred cannot be read from this step: it runs at default chunk sizes (method field: "Default chunk sizes"). C0 already contains the WP2 code, so that cost is in A as well as B.

The pre-registration says only "reported against C0" for g03, not "under the policy above". I flag these rows as NEEDS-ATTENTION and do not call them a FAIL.

### g05-pending
Fields: `rows[*].minimum` and `median`, matched on lines, chunk_size, payload, hint, iter_batches and sha256. Each row has 15 samples.

**Scaling:** B is +1.7% to +4.0% slower than A on every scaling row (both engines, by min). That is below 5% and does not affect linearity.

**Flagged bulk row:** `C/g05-pending-bulk-4m-repetitive-zlib-ng-{A,B}.json` `rows[2]` (`readlines(8192)`).
- A samples are 107.5–109.5 ms; B samples are 115.7–117.7 ms. The distributions are tight and do not overlap.
- On stdlib the same row is +2.53% (`C/g05-pending-bulk-4m-repetitive-stdlib-*.json` `rows[2]`).
- The 4m-varied zlib-ng `readlines(8192)` row is +0.16%.
- B ran first on zlib-ng, and there is one capture per side, so drift cannot be separated from the code change.

### g06-longline-resources
Method: group rows by `case` minus `size`, then take the ratio of `samples[0].work.growing_buffer_characters` and of `samples[0].work.append_calls` between size s and 2s. This is the same derivation as `plans/benchmarks/v2.0.0b2-wp5-longline-resources.md`.

The 24 doubling pairs are 3 contents × 2 generic newlines × 4 pairs. All other families have zero work.

The append-call ratio 1.9697 is ISO-2022-JP 33→65 calls, present on both sides. The B 16 Mi `newline=""` peaks are 33,602,530 (UTF-8), 69,471,398 (ISO) and 33,630,314/258 (Latin-1). These match the G06 candidate record (33,602,426 / 69,471,294 / 33,630,218) within about 100 bytes.

### g06-longline-timing
**Method:** for each family with 8 MiB and 16 MiB rows, I computed `min_seconds(16 MiB)/min_seconds(8 MiB)`, and the same with `median_seconds`. `scripts/summarize_b2_observations.py` `scaling()` uses per-capture minima, and the recorded 2.04–2.66 range is the median of those minima ratios across 4 blocks. Here there is one capture per side, so the min-ratio is the direct analogue.

"Generic" means `newline` `""` and `"\r\n"`, as in the batch-2 record.

**Interpretation:** the criterion is that the candidate's ratios fall within the disposition: about 2.04–2.66, with rows above 2.5 and ISO-2022-JP rows accepted, and no return to the quadratic baseline (stdlib 2.94–4.56, zlib-ng 3.69–4.97).

**Not gated by this criterion:** per-row B/A timing on zlib-ng (`C/g06-longline-timing-zlib-ng-*.json`) has three rows >10% by min. All are fast-path or short-chunk rows:

| Row | Min, ms | Min Δ | Median Δ |
| --- | --- | ---: | ---: |
| UTF-8 `newline=None`, 8 MiB, 64 KiB chunk | 1.539→1.747 | +13.55% | +14.33% |
| UTF-8 `"\n"`, 1 MiB, 256 KiB chunk, crlf ending | 0.194→0.218 | +12.18% | |
| UTF-8 `"\n"`, 1 MiB, 256 KiB chunk, trailing-cr ending | 0.192→0.212 | +10.29% | |

- The 16 MiB row of the UTF-8 `None` family is −0.2%. This is why B's doubling ratio for that family (2.347) is lower than A's (2.671).
- Per-row median of deltas: zlib-ng +0.02%, stdlib +0.05%. Stdlib has no row >5%.
- The protocol judges these rows by the runner captures, not this step. I report them for completeness.

### g07-read-latency
Fields: `rows[*].ticker_ticks`, `handles[*].first_result_seconds`, `handles[*].error.type`, `binary_eof`, `returned`, `cohort_seconds`, `max_gap_seconds`.

**Interpreting "cohort max/min":** I checked this against the archived batch-1 raw data, extracted to the scratchpad from `plans/benchmarks/data/b2/wp5-batch1-20261003/g07-both.tar.xz`. The WP5 statement "no cohort max/min ratio exceeds 1.5" holds only as the per-group max/min of `cohort_seconds` across rounds (worst 1.321 stdlib, 1.310 zlib-ng). The ratio of handle `first_result_seconds` within a cohort reached 3.58 and 4.72 in that same accepted data.

With `--repeat 1` there is one observation per group per side. I therefore applied the criterion three ways:
- **Within one side:** trivially 1.0.
- **A against B per group:** worst 1.110 (stdlib) and 1.181 (zlib-ng; fault=limit, 16 MiB, nonseekable read).
- **Each side pooled with the six batch-1 rounds, which ran the same `src` as C0:** stdlib worst 1.441 (A) and 1.457 (B). On zlib-ng, two groups exceed 1.5 for both A (1.741) and B (1.773): repeated-x 1 MiB, one handle, nonseekable `read` and seekable `readinto`. In those groups the new runs are **faster** (0.39–0.40 ms against batch-1 0.52–0.69 ms), with A and B alike. The cause is host or session state, not the candidate.

Expected error outcomes: on every row and both engines, the sequence of handle outcomes (output, eof, or error type) equals A's and equals the outcome set in all six batch-1 rounds.

Worst `max_gap_seconds`:
- stdlib: A 0.03973, B 0.03988 (repeated-x 32 MiB, 4 handles, nonseekable readline).
- zlib-ng: A 0.03863, B 0.03825.

### g07-read-resources
Fields: `rows[*].inflation.total_inflated_bytes` and `rows[*].tracemalloc_peak_bytes`. Matched on `case`; `fixture` is identical.

The seekable binary `read(1)` table reproduces the WP5 resource record exactly (`plans/benchmarks/v2.0.0b2-wp5-read-resources.md`): inflated 1,048,576 / 4,194,304 / 16,777,216 / 67,108,864 / 33,554,432 / 134,217,728.

| Case | stdlib peak, A→B | zlib-ng peak, A→B |
| --- | --- | --- |
| 1 MiB ×1 | 2,101,048 → 2,101,048 | 2,101,048 → 2,101,048 |
| 1 MiB ×4 | 5,382,538 → 5,382,538 | 5,389,210 → 5,389,210 |
| 16 MiB ×1 | 33,600,761 → 33,600,761 | same |
| 16 MiB ×4 | 84,075,479 → 84,075,479 | 84,082,151 → 84,082,151 |
| 32 MiB ×1 | 69,255,601 → 69,255,601 | same |
| 32 MiB ×4 | 176,313,681 → 176,313,625 | same as stdlib |

All 104 rows per engine have identical `inflation` dicts. The per-handle fields `returned`, `compressed_bytes_fetched`, `inflated_accounted_bytes`, `binary_unread_bytes`, `text_unread_characters`, `compressed_cache_bytes`, `validated_members`, `binary_eof` and `round_trip_verified` are also identical.

### g08
**Throughput:** `rows[*].min_seconds` and `median_seconds`, matched on case, fixture, direction and hashes. The G08 accepted costs were measured against WP4 and are already inside A, since C0 has the same `src` as 2f78925. B against A shows no row above +2.29% by min (`C/g08-fairness-throughput-zlib-ng-*.json` `rows[5]`, 4 KiB random decompress).

**Latency:** `rows[*].samples[*].ticks`, `ticks_before_final_item`, `max_items_between_ticks` and `max_gap_seconds`. `latency-large` cases have one source item, so `ticks_before_final_item` = 0 is structural there and not a starvation signal; their ticks stay above 0. One variance note: zlib-ng `latency-large` text compress ticks range 3–689 on B against 3–3 on A, and this metric is not gated.

## Items that fail or need attention

No step FAILS its pre-registered criterion. The following need attention:

1. **g05-pending-bulk-4m-repetitive, zlib-ng, `readlines(8192)`.** +7.68% by min and +8.04% by median.
   - Values: `C/g05-pending-bulk-4m-repetitive-zlib-ng-A.json` `rows[2].minimum` = 0.107480 s against `-B.json` `rows[2].minimum` = 0.115730 s. The 15-sample distributions do not overlap.
   - Under the policy (>5%), this needs an investigation and a recorded disposition. It is below the 10% blocking level.
   - Stdlib is +2.53% on the same row. zlib-ng 4m-varied `readlines(8192)` is +0.16%.
   - Single capture per side, with zlib-ng running B first.
2. **g03-source-reads, zlib-ng, three rows >5% by min** (`C/g03-source-reads-zlib-ng-{A,B}.json`, `rows[i].minimum_seconds`):
   - `rows[19]` custom binary read-sized, random: **+15.7%** (0.611→0.706 ms), a consistent shift across all 11 samples.
   - `rows[21]` custom text read-all, random: +9.2% (4.826→5.271 ms). B samples are bimodal.
   - `rows[12]` native binary read-all, random: +5.7% (0.973→1.029 ms).

   The criterion for this step is correctness plus "reported against C0", with no percentage rule stated. If the reviewers apply the §15.1 policy here too, `rows[19]` exceeds 10% and needs an attribution check. These are sub-millisecond rows from one capture each, and zlib-ng ran B first.
3. **g06-longline-timing, zlib-ng, ISO-2022-JP generic doubling ratios above the recorded 2.66 top.**
   - Values: 2.747 (`""`) and 2.759 (`"\r\n"`) by min; 2.787 by median.
   - I count this as PASS because the disposition accepts ISO-2022-JP rows and rows above 2.5, and C0 shows 2.667/2.732 for the same families.
   - Reviewers may want this noted explicitly, since the recorded range was 2.04–2.66.
4. **Informational only, outside the criteria for these steps:**
   - zlib-ng g06 timing rows +13.55%, +12.18% and +10.29% B against A on fast paths (see the g06 timing section).
   - g02 zlib-ng decode 1 MiB and 4 MiB rows are noisy on B (+71.7% and +75.3% by median, +12.2% and +15.7% by min), and stdlib A is equally noisy when it runs first.
   - Every zlib-ng flag above comes from a B-first ordering, and the stdlib run (A first) shows A-side outliers of the same kind on g02 decode. A side-order or warm-up effect is plausible, but these data cannot establish it.
5. **g07-read-latency cohort interpretation.**
   - The WP5 "cohort max/min ≤1.5" was computed across 6 rounds per group. With `--repeat 1` it cannot be computed the same way.
   - I used A/B per group (worst 1.181) and pooling with batch 1. Pooled, two zlib-ng groups reach 1.74–1.77 on both A and B, because the new runs are faster.
   - Reviewers should confirm which interpretation G17 intends.

Scratch scripts (not repository files) are in `/tmp/claude-1000/-home-geoff-Projects-personal-aiogzip/ed2d880c-00c7-43cd-92df-0341e13ebc8a/scratchpad/`: `g07lat.py`, `g05s.py`, `g06r.py`, `g06t.py`, `g07r.py`. The batch-1 G07 raw data is extracted to `b1/` there.
