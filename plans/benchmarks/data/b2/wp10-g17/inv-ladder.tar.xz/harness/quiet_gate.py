"""Quiet gate and foreign-CPU monitor for the WP10 (G17) benchmark windows.

Self-contained (no imports from the mutable checkout). Foreign CPU is the WP5
runner's measure: host busy time from /proc/stat minus this service cgroup's
usage, in cores, sampled every 5 s.

    quiet_gate.py gate      exit 0 after 120 s at <= 2.5 cores; exit 1 if that
                            never happens within 30 minutes
    quiet_gate.py monitor   print "<epoch> <cores>" every 5 s until killed
"""

import os
import sys
import time
from pathlib import Path

CEILING, QUIET, SAMPLE, LIMIT = 2.5, 120, 5, 1800


def _cgroup():
    relative = next(
        line[3:]
        for line in Path("/proc/self/cgroup").read_text().splitlines()
        if line.startswith("0::")
    )
    return Path("/sys/fs/cgroup") / relative.lstrip("/")


def _snapshot(cgroup):
    fields = Path("/proc/stat").read_text().splitlines()[0].split()[1:]
    ticks = [int(n) for n in fields]
    busy = sum(ticks[i] for i in (0, 1, 2, 5, 6, 7)) / os.sysconf("SC_CLK_TCK")
    usage = dict(
        line.split() for line in (cgroup / "cpu.stat").read_text().splitlines()
    )
    return time.monotonic(), busy, int(usage["usage_usec"]) / 1e6


def _sample(cgroup):
    before = _snapshot(cgroup)
    time.sleep(SAMPLE)
    after = _snapshot(cgroup)
    elapsed = after[0] - before[0]
    return max(0.0, (after[1] - before[1] - (after[2] - before[2])) / elapsed)


def gate(cgroup):
    start = since = time.monotonic()
    while time.monotonic() - start < LIMIT:
        cores = _sample(cgroup)
        print(f"{time.time():.6f} {cores:.3f}", flush=True)
        if cores > CEILING:
            since = time.monotonic()
        elif time.monotonic() - since >= QUIET:
            print("quiet", flush=True)
            return 0
    print("deferred: host never quiet for 120 s within 30 minutes", flush=True)
    return 1


def monitor(cgroup):
    while True:
        cores = _sample(cgroup)
        print(f"{time.time():.6f} {cores:.3f}", flush=True)


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "gate":
        sys.exit(gate(_cgroup()))
    if mode == "monitor":
        monitor(_cgroup())
    sys.exit(f"unknown mode {mode!r}")
