#!/usr/bin/env bash
# G17 confirmations (amendment 4): each adjacent-commit pair in
# manifest-confirm.json, earlier commit (A) against later commit (B), runner
# categories only, ABBA ABBA per engine, pinned to CPU 13 behind the quiet
# gate. Every input comes from manifest-confirm.json, pinned in
# harness.sha256; the systemd unit pins the hashes of this script and of
# harness.sha256.
set -euo pipefail
REPO=/home/geoff/Projects/personal/aiogzip
BENCH=$REPO/.cache/wp10-bench
PY=$REPO/.venv/bin/python
UV=/home/geoff/.local/bin/uv
CPU=13
ROOTS=/tmp/aiogzip-g17-confirm
RUNNER=$ROOTS/runner
cd "$BENCH"
sha256sum --check --strict --quiet harness.sha256 || { echo "harness hash mismatch"; exit 1; }
MANIFEST=$BENCH/manifest-confirm.json
field() { "$PY" -c 'import json,sys; v=json.load(open(sys.argv[1]))
for k in sys.argv[2:]: v=v[int(k)] if isinstance(v, list) else v[k]
print(" ".join(v) if isinstance(v, list) else v)' "$MANIFEST" "$@"; }
count() { "$PY" -c 'import json,sys; print(len(json.load(open(sys.argv[1]))["pairs"]))' "$MANIFEST"; }
[ "$(field mode)" = confirm ] || { echo "manifest mode mismatch"; exit 1; }
RUNNER_SHA=$(field runner)
CATEGORIES=$(field categories)
cd "$REPO"

OUT=$BENCH/confirm-$(date +%Y%m%d-%H%M%S)
mkdir -p "$OUT"
cp "$MANIFEST" "$OUT/manifest.json"

# Fresh worktrees at the exact pinned commits: the runner, then one per
# distinct pair commit (a commit shared by two pairs gets one worktree).
if [ -e "$ROOTS" ]; then
  shopt -s nullglob
  for w in "$ROOTS"/*; do git worktree remove --force "$w"; done
  shopt -u nullglob
  rmdir "$ROOTS"
fi
git worktree prune
mkdir -p "$ROOTS"
PAIRS=$(count)
declare -a LABELS AS BS
for ((p = 0; p < PAIRS; p++)); do
  LABELS[p]=$(field pairs "$p" label); AS[p]=$(field pairs "$p" a); BS[p]=$(field pairs "$p" b)
done
git worktree add -q --detach "$RUNNER" "$RUNNER_SHA"
for sha in $(printf '%s\n' "${AS[@]}" "${BS[@]}" | sort -u); do
  git worktree add -q --detach "$ROOTS/$sha" "$sha"
done
for sha in $(printf '%s\n' "${AS[@]}" "${BS[@]}" | sort -u) runner; do
  if [ "$sha" = runner ]; then w=$RUNNER; sha=$RUNNER_SHA; else w=$ROOTS/$sha; fi
  [ "$(git -C "$w" rev-parse HEAD)" = "$sha" ] || { echo "commit mismatch $w"; exit 1; }
  [ -z "$(git -C "$w" status --porcelain)" ] || { echo "dirty $w"; exit 1; }
done
[ "$(git rev-parse "$RUNNER_SHA:benchmarks")" = "$(field runner_benchmarks_tree)" ] || { echo "runner benchmarks tree mismatch"; exit 1; }
[ "$(git rev-parse "$RUNNER_SHA:scripts")" = "$(field runner_scripts_tree)" ] || { echo "runner scripts tree mismatch"; exit 1; }
[ "$(sha256sum < "$RUNNER/uv.lock" | cut -c1-64)" = "$(field uv_lock_sha256)" ] || { echo "runner uv.lock mismatch"; exit 1; }
[ "$(sha256sum < uv.lock | cut -c1-64)" = "$(field uv_lock_sha256)" ] || { echo "main uv.lock mismatch"; exit 1; }
"$UV" sync --locked --all-extras --check > "$OUT/uv-sync-check.log" 2>&1 || { echo "venv not in sync with uv.lock"; exit 1; }
[ "$("$PY" "$BENCH/envcheck.py" "$OUT/environment.json")" = "$(field env_fingerprint)" ] || { echo "environment fingerprint mismatch"; exit 1; }

if ! "$PY" "$BENCH/quiet_gate.py" gate > "$OUT/quiet-gate.log" 2>&1; then
  echo "deferred: see $OUT/quiet-gate.log"
  exit 0
fi

{
  date; uptime
  cat "$BENCH/harness.sha256"
  sha256sum "$BENCH/confirm.sh" "$BENCH/harness.sha256"
} > "$OUT/provenance.txt"

"$PY" "$BENCH/quiet_gate.py" monitor > "$OUT/foreign.log" 2>&1 &
MONITOR=$!
trap 'kill "$MONITOR" 2>/dev/null || true' EXIT

printf 'engine\tn\tside\tstep\tstart\tend\n' > "$OUT/captures.tsv"
record() {  # engine n side step start
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$1" "$2" "$3" "$4" "$5" "$(date +%s.%N)" >> "$OUT/captures.tsv"
}

for ((p = 0; p < PAIRS; p++)); do
  label=${LABELS[p]}
  for engine in stdlib zlib-ng; do
    n=0
    for side in A B B A A B B A; do
      n=$((n+1))
      sha=${AS[p]}; [ "$side" = B ] && sha=${BS[p]}
      start=$(date +%s.%N)
      # A failed capture refuses the pair, so stop at once.
      taskset -c "$CPU" "$PY" "$RUNNER/benchmarks/run_benchmarks.py" \
        --category "$CATEGORIES" --repeat 5 \
        --engine "$engine" --source-root "$ROOTS/$sha" \
        --output "$OUT/$label-$engine-$n-$side.json" < /dev/null > "$OUT/$label-$engine-$n-$side.log" 2>&1
      record "$engine" "$label-$n" "$side" runner "$start"
    done
    echo "$label $engine done $(date +%T)"
  done
done
sleep 6  # one more monitor sample after the last capture
echo "results in $OUT"
