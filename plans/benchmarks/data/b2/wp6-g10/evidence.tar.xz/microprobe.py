"""Targeted micro-test for the two flagged stdlib WP6 benchmarks."""
import asyncio, gzip, os, random, statistics, sys, tempfile, time
root, workload, iterations = sys.argv[1], sys.argv[2], int(sys.argv[3])
os.environ["AIOGZIP_ENGINE"] = "stdlib"
sys.path.insert(0, os.path.join(root, "src"))
import aiogzip
assert aiogzip.__file__.startswith(root)
from aiogzip import AsyncGzipBinaryFile, AsyncGzipTextFile
d = tempfile.mkdtemp()
if workload == "text":
    path = os.path.join(d, "t.gz")
    n = 1024 * 1024
    with open(path, "wb") as f:
        f.write(gzip.compress(("x" * n).encode()))
    async def op():
        async with AsyncGzipTextFile(path, "rt", chunk_size=64 * 1024) as f:
            await f.read(n)
else:
    path = os.path.join(d, "s.gz")
    data = random.Random(0).randbytes(4 * 1024 * 1024)
    c = bytearray(gzip.compress(data, mtime=0)); c[-8] ^= 1
    with open(path, "wb") as f:
        f.write(c)
    async def op():
        async with AsyncGzipBinaryFile(path, "rb") as f:
            try:
                await f.read()
            except gzip.BadGzipFile:
                pass
            assert len(await f.read()) == len(data)
async def main():
    for _ in range(5):
        await op()
    times = []
    for _ in range(iterations):
        t = time.perf_counter(); await op(); times.append(time.perf_counter() - t)
    print(f"{min(times)*1e6:.1f} {statistics.median(times)*1e6:.1f}")
asyncio.run(main())
