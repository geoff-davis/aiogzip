#!/usr/bin/env bash
# G17 functional preflight. Not evidence: unpinned, no quiet gate, minimal
# repeats. For each root in manifest-preflight.json (c0, wp0, candidate) and
# each engine, it runs the window's runner categories once, the write sizes
# with five samples (bench_a3_regressions' minimum odd repeat), and every
# structural-c0.txt step once with its registered options. It
# records each step's duration and exit status, then summarize.py freezes the
# expected row sets (expected-rows.json) that the windows are validated
# against. Inputs are pinned exactly as in run.sh.
set -uo pipefail
REPO=/home/geoff/Projects/personal/aiogzip
BENCH=$REPO/.cache/wp10-bench
PY=$REPO/.venv/bin/python
UV=/home/geoff/.local/bin/uv
RUNNER=/tmp/aiogzip-g17-runner
cd "$BENCH" || exit 1
sha256sum --check --strict --quiet harness.sha256 || { echo "harness hash mismatch"; exit 1; }
MANIFEST=$BENCH/manifest-preflight.json
field() { "$PY" -c 'import json,sys; d=json.load(open(sys.argv[1])); v=d
for k in sys.argv[2:]: v=v[k]
print(v)' "$MANIFEST" "$@"; }
[ "$(field mode)" = preflight ] || { echo "manifest mode mismatch"; exit 1; }
RUNNER_SHA=$(field runner)
CATEGORIES=$(field categories)
cd "$REPO" || exit 1

OUT=$BENCH/preflight-$(date +%Y%m%d-%H%M%S)
mkdir -p "$OUT/structural"
cp "$MANIFEST" "$OUT/manifest.json"
cp "$BENCH/structural-c0.txt" "$OUT/structural-c0.txt"

set -e
declare -A ROOT
ROOT[runner]=$RUNNER
for role in c0 wp0 candidate; do ROOT[$role]=/tmp/aiogzip-g17-pf-$role; done
for w in "${ROOT[@]}"; do
  if [ -e "$w" ]; then git worktree remove --force "$w"; fi
done
git worktree prune
git worktree add -q --detach "$RUNNER" "$RUNNER_SHA"
for role in c0 wp0 candidate; do
  sha=$(field roots "$role")
  git worktree add -q --detach "${ROOT[$role]}" "$sha"
done
for role in runner c0 wp0 candidate; do
  w=${ROOT[$role]}
  if [ "$role" = runner ]; then sha=$RUNNER_SHA; else sha=$(field roots "$role"); fi
  [ "$(git -C "$w" rev-parse HEAD)" = "$sha" ] || { echo "commit mismatch $w"; exit 1; }
  [ -z "$(git -C "$w" status --porcelain)" ] || { echo "dirty $w"; exit 1; }
done
[ "$(git rev-parse "$RUNNER_SHA:benchmarks")" = "$(field runner_benchmarks_tree)" ] || { echo "runner benchmarks tree mismatch"; exit 1; }
[ "$(git rev-parse "$RUNNER_SHA:scripts")" = "$(field runner_scripts_tree)" ] || { echo "runner scripts tree mismatch"; exit 1; }
[ "$(sha256sum < "$RUNNER/uv.lock" | cut -c1-64)" = "$(field uv_lock_sha256)" ] || { echo "runner uv.lock mismatch"; exit 1; }
[ "$(sha256sum < uv.lock | cut -c1-64)" = "$(field uv_lock_sha256)" ] || { echo "main uv.lock mismatch"; exit 1; }
"$UV" sync --locked --all-extras --check > "$OUT/uv-sync-check.log" 2>&1 || { echo "venv not in sync with uv.lock"; exit 1; }
[ "$("$PY" "$BENCH/envcheck.py" "$OUT/environment.json")" = "$(field env_fingerprint)" ] || { echo "environment fingerprint mismatch"; exit 1; }
set +e

{ date; uptime; cat "$BENCH/harness.sha256"; sha256sum "$BENCH/preflight.sh" "$BENCH/harness.sha256"; } > "$OUT/provenance.txt"
printf 'role\tengine\tstep\tseconds\tstatus\n' > "$OUT/durations.tsv"
step() {  # role engine label command...
  local role=$1 engine=$2 label=$3; shift 3
  local start; start=$(date +%s.%N)
  "$@" < /dev/null > "$OUT/logs-$role-$engine-$label.log" 2>&1
  local status=$?
  printf '%s\t%s\t%s\t%s\t%s\n' "$role" "$engine" "$label" \
    "$(awk -v a="$start" -v b="$(date +%s.%N)" 'BEGIN { printf "%.3f", b - a }')" \
    "$status" >> "$OUT/durations.tsv"
  echo "$role $engine $label exit $status $(date +%T)"
}

for engine in stdlib zlib-ng; do
  for role in c0 wp0 candidate; do
    root=${ROOT[$role]}
    step "$role" "$engine" runner "$PY" "$RUNNER/benchmarks/run_benchmarks.py" \
      --category "$CATEGORIES" --repeat 1 \
      --regression-profile quick --regression-mode throughput \
      --engine "$engine" --source-root "$root" --output "$OUT/$role-$engine.json"
    step "$role" "$engine" writes "$PY" "$RUNNER/benchmarks/bench_a3_regressions.py" \
      --categories writes --repeat 5 \
      --engine "$engine" --source-root "$root" --output "$OUT/$role-$engine-writes.json"
    while IFS='|' read -r label engines script args; do
      if [ -z "$label" ] || [ "${label#\#}" != "$label" ]; then continue; fi
      case " $engines " in *" $engine "*) ;; *) continue ;; esac
      engine_args=(--engine "$engine")
      [ "$script" = measure_b2_partial_read.py ] && engine_args=()
      # shellcheck disable=SC2086
      step "$role" "$engine" "$label" "$PY" "$RUNNER/scripts/$script" \
        --source-root "$root" "${engine_args[@]}" $args \
        --output "$OUT/structural/$role-$label-$engine.json"
    done < "$BENCH/structural-c0.txt"
  done
done
echo "preflight results in $OUT"
"$PY" "$BENCH/summarize.py" preflight "$OUT"
