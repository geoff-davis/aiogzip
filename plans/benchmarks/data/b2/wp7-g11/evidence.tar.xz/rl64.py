import asyncio, gzip, os, sys, tempfile, time
import aiogzip
from aiogzip import AsyncGzipTextFile
assert aiogzip.__file__.startswith(sys.argv[1]), aiogzip.__file__
data = "".join(f"行 {i:06d} 日本語のテキスト\n" for i in range(20_000))
path = os.path.join(tempfile.mkdtemp(), "f.gz")
with gzip.open(path, "wt", encoding="utf-8") as f: f.write(data)
async def once():
    async with AsyncGzipTextFile(path, "rt", encoding="utf-8") as f:
        while await f.readlines(64): pass
async def main():
    best = []
    for _ in range(7):
        ts = []
        for _ in range(10):
            t = time.perf_counter(); await once(); ts.append(time.perf_counter() - t)
        best.append(min(ts))
    print(f"{min(best)*1e3:.4f}")
asyncio.run(main())
