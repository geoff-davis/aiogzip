"""Validate and summarize G17 preflight and window results.

    summarize.py preflight DIR   validate the preflight, print step durations,
                                 and write DIR/expected-rows.json
    summarize.py window DIR      validate a window against window.json and
                                 the pinned expected-rows.json, then compare
    summarize.py ladder DIR      validate investigation I1 and report each
                                 adjacent-commit boundary per round
    summarize.py order DIR       validate investigation I2 and report the
                                 ABBA pair deltas and the G07 rounds

A window is refused when a capture or step is missing, failed, mislabeled,
from the wrong commit, runner or engine, or has a row set other than the one
the preflight froze for that role (C0, WP0 or candidate) and engine, or when
foreign CPU exceeds 2.5 cores or its samples do not cover every capture and
step. The primary statistic is the per-benchmark minimum of the four capture
medians on each side (CLAUDE.md method A), for the runner categories and the
write sizes alike, with the four adjacent A/B pair deltas. Structural steps
are validated (provenance, engine, row set) and their files listed; they are
judged against each gate's recorded criterion, not by percentage.
"""

import json
import math
import sys
from pathlib import Path

ORDER = ["A", "B", "B", "A", "A", "B", "B", "A"]
PAIRS = [(1, 2), (4, 3), (5, 6), (8, 7)]  # (A capture, adjacent B capture)
WRITE_SIZES = [10, 100, 1024, 4096, 16384, 65536, 262144]
WRITE_METHODS = ["write", "writelines", "batch-65536", "batch-262144"]
ENGINES = ("stdlib", "zlib-ng")
CEILING = 2.5
SAMPLE = 5.0
SLACK = 1.0  # sampling overhead per 5 s interval
BENCH = Path(__file__).resolve().parent
# Numeric case parameters and fixture sizes per structural script. A number
# under one of these keys, at any depth of a row, is part of the row's
# identity and kept verbatim; every other number is a measurement and masked.
IDENTITY = {
    "measure_b2_native_settlement.py": {"payload_bytes", "iterations"},
    "measure_b2_source_reads.py": {"payload_bytes", "wire_bytes"},
    "measure_b2_pending_lines.py": {"lines", "chunk_size", "hint"},
    "measure_b2_scaling.py": {"size", "hint", "compressed_bytes", "logical_characters"},
    "measure_b2_long_lines.py": {
        "size",
        "chunk_size",
        "binary_chunk_size",
        "compressed_bytes",
        "encoded_bytes",
        "input_characters",
        "returned_characters",
        "returned_lines",
    },
    "measure_b2_read_resources.py": {
        "size",
        "handles",
        "limit",
        "payload_bytes",
        "compressed_bytes",
        "source_chunk_size",
    },
    "measure_b2_partial_read.py": {
        "payload_bytes",
        "compressed_bytes",
        "source_chunk_size",
    },
    "measure_b2_stream_fairness.py": set(),
}


def fail(message):
    sys.exit(f"INVALID: {message}")


def check(name, checks):
    for key, (actual, wanted) in checks.items():
        if actual != wanted:
            fail(f"{name}: {key} is {actual!r}, expected {wanted!r}")


def positive(name, value):
    """A finite, strictly positive measurement."""
    if not finite(value) or value <= 0:
        fail(f"{name} is {value!r}, expected a finite positive number")
    return value


def finite(value):
    return number(value) and math.isfinite(value)


def decompression(engine):
    return "zlib-ng" if engine == "zlib-ng" else "stdlib-zlib"


def read_json(path):
    if not path.is_file():
        fail(f"missing {path}")
    return json.loads(path.read_text())


def runner_rows(path, *, sha, runner, engine, categories, repeat):
    data = read_json(path)
    check(
        path.name,
        {
            "status": (data.get("status"), "complete"),
            "categories": (data.get("categories"), categories),
            "completed": (data.get("completed_categories"), categories),
            "repeat": (data.get("repeat"), repeat),
            # run_benchmarks.py records these only when regressions is selected
            "regression_profile": (
                data.get("regression_profile"),
                "quick" if "regressions" in categories else None,
            ),
            "regression_mode": (
                data.get("regression_mode"),
                "throughput" if "regressions" in categories else None,
            ),
            "target_commit": (data["source"].get("target_commit"), sha),
            "target_dirty": (data["source"].get("target_dirty"), False),
            "runner_commit": (data["environment"].get("runner_commit"), runner),
            "requested_engine": (data["environment"].get("requested_engine"), engine),
            "decompression": (
                data["environment"]["active_engines"]["decompression"],
                decompression(engine),
            ),
        },
    )
    rows = {}
    memory = {}
    for r in data["results"]:
        key = (r["category"], r["name"])
        if key in rows:
            fail(f"{path.name}: duplicate row {key}")
        rows[key] = positive(f"{path.name}: {key} duration", r.get("duration"))
        if r["category"] == "memory":
            # bench_memory records the increase formatted, e.g. "12.3".
            increase = (r.get("metrics") or {}).get("memory_increase_mb")
            try:
                increase = float(increase)
            except (TypeError, ValueError):
                fail(f"{path.name}: {key} memory_increase_mb is {increase!r}")
            if not finite(increase):
                fail(f"{path.name}: {key} memory_increase_mb is {increase!r}")
            memory[r["name"]] = increase
    return rows, memory


def write_rows(path, *, sha, runner, engine, repeat):
    data = read_json(path)
    config = data["configuration"]
    check(
        path.name,
        {
            "categories": (config.get("categories"), ["writes"]),
            "write_sizes": (config.get("write_sizes"), WRITE_SIZES),
            "repeat": (config.get("repeat"), repeat),
            "commit": (data["source"].get("commit"), sha),
            "dirty": (data["source"].get("dirty_tracked"), False),
            "runner_commit": (data["environment"].get("runner_commit"), runner),
            "requested_engine": (data["source"].get("requested_engine"), engine),
        },
    )
    expected = {
        f"{method} {size}B records" for size in WRITE_SIZES for method in WRITE_METHODS
    }
    results = data["results"]
    names = [r["name"] for r in results]
    if len(names) != len(set(names)) or set(names) != expected:
        fail(f"{path.name}: unexpected write result set")
    for r in results:
        if r.get("status") != "ok" or r.get("sample_count") != repeat:
            fail(f"{path.name}: {r['name']} status {r.get('status')!r}")
    fixtures = data.get("fixtures")
    if not fixtures:
        fail(f"{path.name}: no fixture identities")
    medians = {
        ("writes", r["name"]): positive(
            f"{path.name}: {r['name']} median", r.get("median_seconds")
        )
        for r in results
    }
    return medians, fixtures


def structural_identity(path, *, sha, runner, engine, script):
    """Common provenance of a measure_b2_* output, and its row signature."""
    data = read_json(path)
    if isinstance(data.get("source"), dict):
        source, harness = data["source"], data["harness"]
        check(
            path.name,
            {
                "source": (source.get("sha"), sha),
                "source clean": (source.get("status"), ""),
                "harness": (harness.get("sha"), runner),
                "harness clean": (harness.get("status"), ""),
            },
        )
        engines = data.get("engines")
    else:  # measure_b2_pending_lines.py records flat identity fields
        check(
            path.name,
            {
                "commit": (data.get("commit"), sha),
                "harness_commit": (data.get("harness_commit"), runner),
            },
        )
        engines = data.get("engine")
    if not isinstance(engines, dict):
        fail(f"{path.name}: no active engines")
    wanted = "stdlib" if script == "measure_b2_partial_read.py" else engine
    check(
        path.name,
        {"decompression": (engines.get("decompression"), decompression(wanted))},
    )
    if "engine_request" in data:
        check(path.name, {"engine_request": (data["engine_request"], engine)})
    rows = data.get("rows")
    if not isinstance(rows, list) or not rows:
        fail(f"{path.name}: no rows")
    if script not in IDENTITY:
        fail(f"{path.name}: no identity fields registered for {script}")
    return signature(rows, IDENTITY[script])


def shape(value, identity, key=None):
    """The value with every measurement replaced by its type, recursively.

    Keys, strings, booleans, nulls and list structure (including lengths) are
    kept at every depth: case labels, flags, digests, nested parameters, and
    numbers under an ``identity`` key. Only measurements are discarded: any
    other number becomes its type name, and a non-empty list of numbers
    becomes one ``list[...]`` of its element types, since timed-budget
    batches (``operation_seconds``) vary in length.
    """
    if isinstance(value, dict):
        return {k: shape(v, identity, k) for k, v in value.items()}
    if isinstance(value, list):
        if value and all(number(v) for v in value):
            return "list[" + "|".join(sorted({type(v).__name__ for v in value})) + "]"
        return [shape(v, identity) for v in value]
    if number(value):
        return value if key in identity else type(value).__name__
    return value


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def signature(rows, identity):
    """The sorted shapes of a step's rows."""
    return sorted(json.dumps(shape(row, identity), sort_keys=True) for row in rows)


def steps(path):
    for line in path.read_text().splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        label, engines, script, args = line.split("|", 3)
        yield label, engines.split(), script, args


def coverage(out):
    """Peak foreign CPU over each capture, from samples that fully cover it.

    A sample at time t covers the interval (t - 5, t]. It overlaps a capture
    [start, end] when start < t and t - 5 < end. Coverage must be continuous
    from before the start to after the end.
    """
    samples = []
    for line in (out / "foreign.log").read_text().splitlines():
        parts = line.split()
        if len(parts) == 2:
            samples.append((float(parts[0]), float(parts[1])))
    peaks = {}
    for row in (out / "captures.tsv").read_text().splitlines()[1:]:
        engine, n, side, step, start, end = row.split("\t")
        start, end = float(start), float(end)
        hits = [(t, c) for t, c in samples if start < t and t - SAMPLE < end]
        if not hits:
            fail(f"{engine} {n} {side} {step} has no foreign-CPU samples")
        times = [t for t, _ in hits]
        gaps = [b - a for a, b in zip(times, times[1:], strict=False)]
        if (
            times[0] - SAMPLE > start + SLACK
            or times[-1] < end
            or any(gap > SAMPLE + SLACK for gap in gaps)
        ):
            fail(f"{engine} {n} {side} {step} is not continuously covered by samples")
        key = (engine, n, side, step)
        if key in peaks:
            fail(f"duplicate capture row {key}")
        peaks[key] = max(c for _, c in hits)
    return peaks


def preflight(out):
    manifest = read_json(out / "manifest.json")
    expected = {}
    print("step durations (s):")
    failed = []
    for line in (out / "durations.tsv").read_text().splitlines()[1:]:
        role, engine, step, seconds, status = line.split("\t")
        print(f"  {role:9} {engine:7} {step:34} {float(seconds):8.1f}  {status}")
        if status != "0":
            failed.append(f"{role} {engine} {step} exited {status}")
    if failed:
        fail("; ".join(failed))
    for role, sha in manifest["roots"].items():
        for engine in ENGINES:
            rows, _ = runner_rows(
                out / f"{role}-{engine}.json",
                sha=sha,
                runner=manifest["runner"],
                engine=engine,
                categories=manifest["categories"].split(","),
                repeat=1,
            )
            _, fixtures = write_rows(
                out / f"{role}-{engine}-writes.json",
                sha=sha,
                runner=manifest["runner"],
                engine=engine,
                repeat=5,  # bench_a3_regressions requires an odd repeat of at least 5
            )
            entry = {
                "runner": sorted(f"{c}::{n}" for c, n in rows),
                "write_fixtures": fixtures,
                "structural": {},
            }
            for label, engines, script, _ in steps(out / "structural-c0.txt"):
                if engine not in engines:
                    continue
                entry["structural"][label] = structural_identity(
                    out / "structural" / f"{role}-{label}-{engine}.json",
                    sha=sha,
                    runner=manifest["runner"],
                    engine=engine,
                    script=script,
                )
            expected[f"{role}/{engine}"] = entry
    for engine in ENGINES:
        base = expected[f"c0/{engine}"]
        for role in manifest["roots"]:
            other = expected[f"{role}/{engine}"]
            for part in ("runner", "write_fixtures"):
                if other[part] != base[part]:
                    print(f"NOTE {role}/{engine}: {part} differs from c0")
            for label, sig in other["structural"].items():
                if sig != base["structural"][label]:
                    print(f"NOTE {role}/{engine}: {label} rows differ from c0")
    target = out / "expected-rows.json"
    target.write_text(json.dumps(expected, indent=2, sort_keys=True) + "\n")
    print(f"wrote {target}")


def window(out):
    win = read_json(out / "window.json")
    expected = read_json(BENCH / "expected-rows.json")
    roles = {"A": win["a_role"], "B": win["b_role"]}
    shas = {"A": win["a"], "B": win["b"]}
    categories = win["categories"].split(",")
    peaks = coverage(out)
    print(
        f"mode {win['mode']}: A {roles['A']} {shas['A'][:12]}  B {roles['B']} {shas['B'][:12]}  runner {win['runner'][:12]}"
    )
    for engine in ENGINES:
        rows, memory = {}, {}
        for n, side in enumerate(ORDER, start=1):
            want = expected[f"{roles[side]}/{engine}"]
            runner, memory[n] = runner_rows(
                out / f"{engine}-{n}-{side}.json",
                sha=shas[side],
                runner=win["runner"],
                engine=engine,
                categories=categories,
                repeat=5,
            )
            if sorted(f"{c}::{name}" for c, name in runner) != want["runner"]:
                fail(f"{engine} capture {n}: runner row set differs from the preflight")
            writes, fixtures = write_rows(
                out / f"{engine}-{n}-{side}-writes.json",
                sha=shas[side],
                runner=win["runner"],
                engine=engine,
                repeat=5,
            )
            if fixtures != want["write_fixtures"]:
                fail(f"{engine} capture {n}: write fixtures differ from the preflight")
            rows[n] = {**runner, **writes}
            for step in ("runner", "writes"):
                peak = peaks.get((engine, str(n), side, step))
                if peak is None:
                    fail(f"{engine} capture {n} {step} has no capture boundaries")
                if peak > CEILING:
                    fail(f"{engine} capture {n} {step} ran with foreign CPU {peak:.2f}")
        print(f"\n== {engine}")
        print(
            "peak foreign cores per capture (runner/writes): "
            + " ".join(
                f"{n}:{peaks[(engine, str(n), s, 'runner')]:.2f}"
                f"/{peaks[(engine, str(n), s, 'writes')]:.2f}"
                for n, s in enumerate(ORDER, start=1)
            )
        )
        print(
            "memory_increase_mb per capture: "
            + " ".join(f"{n}{ORDER[n - 1]}:{memory[n]}" for n in memory)
        )
        flagged, worst = 0, 0.0
        for key in sorted(rows[1]):
            a = [rows[n][key] for n, s in enumerate(ORDER, 1) if s == "A"]
            b = [rows[n][key] for n, s in enumerate(ORDER, 1) if s == "B"]
            delta = (min(b) / min(a) - 1) * 100
            pairs = [(rows[nb][key] / rows[na][key] - 1) * 100 for na, nb in PAIRS]
            mark = "  <-- >5%" if delta > 5 else ""
            flagged += delta > 5
            worst = max(worst, abs(delta))
            print(
                f"{key[0]:12} {delta:+7.2f}%  pairs "
                + " ".join(f"{p:+6.1f}" for p in pairs)
                + f"  A={min(a) * 1000:9.3f}ms  {key[1]}{mark}"
            )
        print(f"{flagged} benchmark(s) more than 5% slower by minimum")
        print(f"largest absolute minimum delta {worst:.2f}%")
    if win["mode"] == "aa":
        return
    print("\n== structural steps (judged against each gate's recorded criterion)")
    for label, engines, script, args in steps(out / "structural" / "steps.txt"):
        for engine in engines:
            for side in ("A", "B"):
                path = out / "structural" / f"{label}-{engine}-{side}.json"
                sig = structural_identity(
                    path,
                    sha=shas[side],
                    runner=win["runner"],
                    engine=engine,
                    script=script,
                )
                if sig != expected[f"{roles[side]}/{engine}"]["structural"][label]:
                    fail(f"{path.name}: row set differs from the preflight")
                peak = peaks.get((engine, label, side, "structural"))
                if peak is None:
                    fail(f"{path.name} has no capture boundaries")
                if peak > CEILING:
                    fail(f"{path.name} ran with foreign CPU {peak:.2f} cores")
                print(
                    f"{path.name:52} peak foreign {peak:.2f}  {script} {args}".rstrip()
                )


FOCUS = [  # rows above 5% in the C0 or WP0 window, reported first
    "Flush operations (100 flushes)",
    "Binary read1 (2MiB, 4KiB buffers)",
    "Binary readinto1 (2MiB, 4KiB buffers)",
    "Binary readline (200KB line, 17-byte chunks)",
    "read(-1) - 1MB file",
    "CRC failure + salvage read() - 4MB",
    "limit break + seek(0) recovery x10",
    "seek(0) rewind x50 - healthy reader",
]
DIRECTIONS = ["F", "R", "R", "F"]


def ladder(out):
    """I1: per engine, every adjacent-commit boundary in each of four rounds.

    A failed step (failures.tsv) excludes that commit from every round of that
    engine; boundaries then span the nearest surviving neighbours. Each row
    reports, per boundary, the four within-round ratios (later commit over
    earlier, as percentages) and the ratio of the per-commit minimums of four.
    A boundary is a stable jump when all four within-round ratios exceed +2%
    (or all fall below -2%).
    """
    manifest = read_json(out / "manifest.json")
    commits = manifest["commits"]
    names = [f"{i:02d}" for i in range(len(commits))]
    categories = manifest["categories"].split(",")
    peaks = coverage(out)
    failed = {engine: set() for engine in ENGINES}
    failures = out / "failures.tsv"
    if failures.exists():
        for line in failures.read_text().splitlines():
            engine, round_, name, status = line.split("\t")
            failed[engine].add(name)
            print(
                f"EXCLUDED {engine} {name} ({commits[int(name)][:12]}): round {round_} exited {status}"
            )
    for engine in ENGINES:
        if {names[0], names[-1]} & failed[engine]:
            fail(f"{engine}: an endpoint (WP0 or the candidate) failed")
        keep = [n for n in names if n not in failed[engine]]
        rows = {}
        for r in range(1, 5):
            for name in keep:
                runner, _ = runner_rows(
                    out / f"{engine}-r{r}-{name}.json",
                    sha=commits[int(name)],
                    runner=manifest["runner"],
                    engine=engine,
                    categories=categories,
                    repeat=5,
                )
                peak = peaks.get((engine, str(r), name, "runner"))
                if peak is None:
                    fail(f"{engine} round {r} {name} has no capture boundaries")
                if peak > CEILING:
                    fail(f"{engine} round {r} {name} ran with foreign CPU {peak:.2f}")
                rows[(r, name)] = runner
        print(
            f"\n== {engine}: {len(keep)} commits, peak foreign {max(peaks[(engine, str(r), n, 'runner')] for r in range(1, 5) for n in keep):.2f}"
        )
        present = {}
        for name in keep:
            sets = {frozenset(rows[(r, name)]) for r in range(1, 5)}
            if len(sets) != 1:
                fail(f"{engine} {name}: row set differs between rounds")
            present[name] = sets.pop()
        everywhere = frozenset.intersection(*present.values())
        keys = frozenset.union(*present.values())
        partial = keys - everywhere
        if partial:
            print(
                f"{len(partial)} row(s) absent at some commit; each is reported"
                " across the commits that have it"
            )
        ordered = sorted(
            keys,
            key=lambda k: (
                k[1] not in FOCUS,
                FOCUS.index(k[1]) if k[1] in FOCUS else 0,
                k,
            ),
        )
        for key in ordered:
            have = [n for n in keep if key in present[n]]
            print(f"\n{key[0]} :: {key[1]}")
            if key in partial:
                print(f"  present at {' '.join(have)}")
            for left, right in zip(have, have[1:], strict=False):
                within = [
                    (rows[(r, right)][key] / rows[(r, left)][key] - 1) * 100
                    for r in range(1, 5)
                ]
                mins = (
                    min(rows[(r, right)][key] for r in range(1, 5))
                    / min(rows[(r, left)][key] for r in range(1, 5))
                    - 1
                ) * 100
                stable = all(w > 2 for w in within) or all(w < -2 for w in within)
                mark = "  <-- stable" if stable else ""
                print(
                    f"  {left}->{right} {commits[int(left)][:8]}..{commits[int(right)][:8]}  "
                    + " ".join(f"{w:+6.1f}" for w in within)
                    + f"  min4 {mins:+6.1f}{mark}"
                )
            if have[0] == keep[0] and have[-1] == keep[-1]:
                ends = (
                    min(rows[(r, keep[-1])][key] for r in range(1, 5))
                    / min(rows[(r, keep[0])][key] for r in range(1, 5))
                    - 1
                ) * 100
                print(f"  endpoints {keep[0]}->{keep[-1]} min4 {ends:+6.1f}")
            else:
                print("  endpoints: row absent at an endpoint")


def statistic(row):
    """A timing row's (minimum, median): the minimum is the statistic the
    final-window structural flags used; the median shows stability."""
    for low, mid in (
        ("minimum_seconds", "median_seconds"),  # g03
        ("min_seconds", "median_seconds"),  # g06
        ("minimum", "median"),  # g05
    ):
        if low in row and mid in row:
            return positive(low, row[low]), positive(mid, row[mid])
    fail(f"row has no minimum and median: {sorted(row)}")


def order(out):
    """I2: each step at positions A B B A per engine, C0 (A) vs candidate (B)."""
    manifest = read_json(out / "manifest.json")
    expected = read_json(BENCH / "expected-rows.json")
    roles = {"A": manifest["a_role"], "B": manifest["b_role"]}
    shas = {"A": manifest["a"], "B": manifest["b"]}
    peaks = coverage(out)
    positions = list(enumerate(["A", "B", "B", "A"], start=1))
    for label, engines, script, args in steps(out / "structural" / "steps.txt"):
        for engine in engines:
            print(f"\n== {label} {engine}: {script} {args}".rstrip())
            data = {}
            for pos, side in positions:
                path = out / "structural" / f"{label}-{engine}-{pos}{side}.json"
                sig = structural_identity(
                    path,
                    sha=shas[side],
                    runner=manifest["runner"],
                    engine=engine,
                    script=script,
                )
                registered = label.removesuffix("-r7")
                want = expected[f"{roles[side]}/{engine}"]["structural"][registered]
                if label.endswith("-r7"):
                    if sorted(set(sig)) != sorted(set(want)) or any(
                        sig.count(s) != 7 for s in set(want)
                    ):
                        fail(
                            f"{path.name}: rows are not seven rounds of the registered set"
                        )
                elif sig != want:
                    fail(f"{path.name}: row set differs from the preflight")
                peak = peaks.get((engine, f"{label}-{pos}", side, "structural"))
                if peak is None:
                    fail(f"{path.name} has no capture boundaries")
                if peak > CEILING:
                    fail(f"{path.name} ran with foreign CPU {peak:.2f} cores")
                print(f"  {path.name} peak foreign {peak:.2f}")
                data[pos] = read_json(path)["rows"]
            if label.endswith("-r7"):
                latency(data, positions)
            else:
                timing(data, script)


def timing(data, script):
    """Per row, for the row minimum (the statistic of the final-window flags)
    and the row median: the two opposite-order pair deltas (2B/1A, 3B/4A) and
    the delta of the per-side minimums. Then each position's minimum, median,
    sample count and sample range."""
    identity = IDENTITY[script]
    stats = {}
    for pos, rows in data.items():
        stats[pos] = {}
        for row in rows:
            key = json.dumps(shape(row, identity), sort_keys=True)
            if key in stats[pos]:
                fail(f"position {pos}: duplicate row {key[:120]}")
            stats[pos][key] = (*statistic(row), samples(row))
    for key in sorted(stats[1]):
        print(f"  {label_of(json.loads(key))}")
        for index, name in ((0, "minimum"), (1, "median")):
            a1, b2, b3, a4 = (stats[p][key][index] for p in (1, 2, 3, 4))
            first, second = (b2 / a1 - 1) * 100, (b3 / a4 - 1) * 100
            both = (min(b2, b3) / min(a1, a4) - 1) * 100
            mark = "  <-- >5%" if both > 5 else ""
            print(
                f"    {name:7} A-first {first:+6.1f}  B-first {second:+6.1f}"
                f"  per-side min {both:+6.1f}{mark}"
            )
        for pos, side in zip((1, 2, 3, 4), "ABBA", strict=True):
            low, mid, values = stats[pos][key]
            print(
                f"    {pos}{side} min {low * 1000:.3f}ms  median {mid * 1000:.3f}ms"
                f"  n={len(values)} range {min(values) * 1000:.3f}..{max(values) * 1000:.3f}ms"
            )


def samples(row):
    """A timing row's samples: ``seconds`` (g03, g05) or each timed batch's
    per-operation ``seconds`` (g06)."""
    if isinstance(row.get("seconds"), list):
        values = row["seconds"]
    elif isinstance(row.get("samples"), list):
        values = [sample.get("seconds") for sample in row["samples"]]
    else:
        fail(f"row has no samples: {sorted(row)}")
    if not values:
        fail("row has no samples")
    return [positive("sample", v) for v in values]


def label_of(row):
    """The identifying strings, booleans and identity numbers of a row."""
    parts = []
    for k, v in sorted(row.items()):
        if k in ("warmup", "samples", "seconds") or k.startswith("host_"):
            continue
        if isinstance(v, str) and v not in ("int", "float") and len(v) != 64:
            v = json.dumps(v)  # quoted, with escaped line endings
        if isinstance(v, dict):
            inner = label_of(v)
            if inner:
                parts.append(f"{k}({inner})")
        elif (
            v not in ("int", "float")
            and not isinstance(v, list)
            and not (isinstance(v, str) and len(v) == 64)
        ):
            parts.append(f"{k}={v}")
    return " ".join(parts)


def latency(data, positions):
    """G07: per group and file, zero-tick check, cohort max/min over the seven
    rounds (the WP5 criterion is at most 1.5), and handle outcomes."""
    worst, pooled = {}, {}
    for pos, side in positions:
        groups = {}
        for row in data[pos]:
            if row.get("ticker_ticks") in (None, 0):
                fail(f"position {pos}: zero-tick group {row['case']}")
            outcome = [h.get("error") for h in row["handles"]]
            groups.setdefault(json.dumps(row["case"], sort_keys=True), []).append(
                (
                    row["repeat"],
                    positive("cohort_seconds", row["cohort_seconds"]),
                    outcome,
                )
            )
        for case, entries in groups.items():
            if sorted(r for r, _, _ in entries) != list(range(7)):
                fail(f"position {pos}: {case} does not have rounds 0-6")
            if len({json.dumps(o) for _, _, o in entries}) != 1:
                fail(f"position {pos}: {case} handle outcomes vary across rounds")
            seconds = [s for _, s, _ in entries]
            worst.setdefault(case, {})[f"{pos}{side}"] = (
                max(seconds) / min(seconds),
                min(seconds),
                entries[0][2],
            )
            pooled.setdefault(case, {}).setdefault(side, []).extend(seconds)
    over = 0
    for case, per in sorted(worst.items()):
        outcomes = {json.dumps(o) for _, _, o in per.values()}
        if len(outcomes) != 1:
            fail(f"{case}: handle outcomes differ between C0 and the candidate")
        ratios = " ".join(f"{p}:{r:.3f}" for p, (r, _, _) in per.items())
        a = min(m for p, (_, m, _) in per.items() if p.endswith("A"))
        b = min(m for p, (_, m, _) in per.items() if p.endswith("B"))
        flag = any(r > 1.5 for r, _, _ in per.values())
        over += flag
        side = pooled[case]
        both = " ".join(f"{k}:{max(v) / min(v):.3f}" for k, v in sorted(side.items()))
        print(
            f"  max/min {ratios}  pooled {both}  B/A min {b / a:.3f}  {case}"
            + ("  <-- >1.5" if flag else "")
        )
    print(f"  {over} group(s) with a within-file cohort max/min above 1.5")


if __name__ == "__main__":
    command, directory = sys.argv[1], Path(sys.argv[2])
    {"preflight": preflight, "window": window, "ladder": ladder, "order": order}[
        command
    ](directory)
