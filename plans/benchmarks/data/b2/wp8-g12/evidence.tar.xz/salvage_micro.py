"""Targeted micro-test: CRC failure + salvage read() of 4 MiB (binary only).

Run once per side with PYTHONPATH=<root>/src; prints the imported module, the
active engines and, per repeat, the mean time of 20 operations in ms.
"""

import asyncio
import gzip
import random
import sys
import tempfile
import time
from pathlib import Path

import aiogzip
from aiogzip import AsyncGzipBinaryFile

DATA = random.Random(0).randbytes(4 * 1024 * 1024)


def corrupt_crc(data):
    wire = bytearray(gzip.compress(data, mtime=0))
    wire[-8] ^= 1
    return bytes(wire)


async def operation(path):
    async with AsyncGzipBinaryFile(path, "rb") as f:
        try:
            await f.read()
        except gzip.BadGzipFile:
            pass
        assert len(await f.read()) == len(DATA)


async def main(repeats, iterations):
    print(aiogzip.__file__, aiogzip.engine_info(), flush=True)
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "salvage.gz"
        path.write_bytes(corrupt_crc(DATA))
        await operation(path)
        for _ in range(repeats):
            start = time.perf_counter()
            for _ in range(iterations):
                await operation(path)
            print(f"{(time.perf_counter() - start) / iterations * 1000:.4f}")


asyncio.run(main(int(sys.argv[1]), int(sys.argv[2])))
