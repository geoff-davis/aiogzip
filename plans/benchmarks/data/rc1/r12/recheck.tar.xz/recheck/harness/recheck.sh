#!/usr/bin/env bash
# R12 re-check: b2, the candidate and the inspection read fix, verify() only.
# Six rounds; in each, every (engine, fixture) runs b2, the candidate (full)
# and the fix in that round's permutation of the three: all six permutations,
# so each takes each position twice and each ordered neighbour pair occurs
# twice. One fresh process per variant, on CPU 13.
# Launched as its own transient systemd service, so the quiet gate and monitor
# subtract exactly this run's cgroup.
set -euo pipefail
REPO=/home/geoff/Projects/personal/aiogzip
BENCH=$REPO/.cache/rc1-bench
PY=$REPO/.venv/bin/python
CPU=13
A=/tmp/aiogzip-r12x-b2
B=/tmp/aiogzip-r12x-cand
C=/tmp/aiogzip-r12x-fix
[ -n "${INVOCATION_ID:-}" ] || { echo "run under systemd-run"; exit 1; }
cd "$BENCH"
sha256sum --check --strict --quiet recheck.sha256 || { echo "harness hash mismatch"; exit 1; }
cd "$REPO"
A_SHA=$(git rev-parse 962bfe4); B_SHA=$(git rev-parse dd70af4); C_SHA=$(git rev-parse f7c03c0)
OUT=$BENCH/recheck-$(date +%Y%m%d-%H%M%S)
mkdir -p "$OUT"
for w in "$A" "$B" "$C"; do
  if [ -e "$w" ]; then git worktree remove --force "$w"; fi
done
git worktree prune
git worktree add -q --detach "$A" "$A_SHA"
git worktree add -q --detach "$B" "$B_SHA"
git worktree add -q --detach "$C" "$C_SHA"
for pair in "$A $A_SHA" "$B $B_SHA" "$C $C_SHA"; do
  set -- $pair
  [ "$(git -C "$1" rev-parse HEAD)" = "$2" ] || { echo "commit mismatch $1"; exit 1; }
  [ -z "$(git -C "$1" status --porcelain)" ] || { echo "dirty $1"; exit 1; }
done
ENV_FP=18d9286b76b256346dd61f51f3ccbf7bf78b788ccd17c07ccdff4fc93543d187
[ "$("$PY" "$BENCH/envcheck.py" "$OUT/environment.json")" = "$ENV_FP" ] || { echo "environment fingerprint mismatch"; exit 1; }
{
  echo "a $A_SHA"; echo "b $B_SHA"; echo "c $C_SHA"; date; uptime; cat /proc/self/cgroup
  sha256sum "$BENCH/recheck.sh" "$BENCH/recheck.sha256"; cat "$BENCH/recheck.sha256"
} > "$OUT/provenance.txt"

if ! "$PY" "$BENCH/quiet_gate.py" gate > "$OUT/quiet-gate.log" 2>&1; then
  echo "deferred: see $OUT/quiet-gate.log"; exit 0
fi
"$PY" "$BENCH/quiet_gate.py" monitor > "$OUT/foreign.log" 2>&1 &
MONITOR=$!
trap 'kill "$MONITOR" 2>/dev/null || true' EXIT

ORDERS=("b2 full fix" "full fix b2" "fix b2 full" "b2 fix full" "fix full b2" "full b2 fix")
printf 'round\tengine\tfixture\tvariant\tstart\tend\n' > "$OUT/runs.tsv"
for round in 1 2 3 4 5 6; do
  for engine in stdlib zlib-ng; do
    for fixture in incompressible compressible; do
      for v in ${ORDERS[$((round - 1))]}; do
        case "$v" in b2) root=$A ;; full) root=$B ;; fix) root=$C ;; esac
        start=$(date +%s.%N)
        taskset -c "$CPU" "$PY" "$BENCH/recheck_verify.py" --source-root "$root" \
          --variant "$v" --fixture "$fixture" --engine "$engine" \
          --output "$OUT/$round-$engine-$fixture-$v.json" < /dev/null
        printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$round" "$engine" "$fixture" "$v" "$start" "$(date +%s.%N)" >> "$OUT/runs.tsv"
      done
    done
  done
  echo "round $round done $(date +%T)"
done
sleep 6
echo "results in $OUT"
