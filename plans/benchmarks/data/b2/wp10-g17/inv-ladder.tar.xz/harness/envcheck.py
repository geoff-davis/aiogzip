"""Fingerprint the installed benchmark environment (G17).

Prints canonical JSON: the interpreter (version, implementation, build,
resolved executable and prefix) and every installed distribution with its
version, sorted. ``fingerprint`` is the sha256 of that JSON without itself.
Self-contained; run with the venv's interpreter.

    envcheck.py OUTPUT.json
"""

import hashlib
import importlib.metadata
import json
import os
import platform
import sys


def main():
    distributions = sorted(
        {
            (d.metadata["Name"].lower().replace("_", "-"), d.version)
            for d in importlib.metadata.distributions()
        }
    )
    record = {
        "python_version": sys.version,
        "implementation": platform.python_implementation(),
        "build": list(platform.python_build()),
        "executable": os.path.realpath(sys.executable),
        "prefix": os.path.realpath(sys.prefix),
        "base_prefix": os.path.realpath(sys.base_prefix),
        "distributions": [f"{name}=={version}" for name, version in distributions],
    }
    canonical = json.dumps(record, sort_keys=True, separators=(",", ":"))
    record["fingerprint"] = hashlib.sha256(canonical.encode()).hexdigest()
    with open(sys.argv[1], "x", encoding="utf-8") as output:
        json.dump(record, output, indent=2, sort_keys=True)
        output.write("\n")
    print(record["fingerprint"])


if __name__ == "__main__":
    main()
