"""Exploratory: harness run() over matrix rows 0..47 with qualification sampling."""
import asyncio, os, sys
root, engine = sys.argv[1], sys.argv[2]
os.environ["AIOGZIP_ENGINE"] = engine
sys.path.insert(0, os.path.join(root, "src"))
sys.path.insert(0, "/home/geoff/Projects/personal/aiogzip/.cache/wp5-qualification-onecore/harness/scripts")
import aiogzip
assert aiogzip.__file__.startswith(root)
import io, contextlib, measure_b2_long_lines as m
cases = m.matrix()[:48]
with contextlib.redirect_stdout(io.StringIO()):
    rows = asyncio.run(m.run(aiogzip, cases, "timing", 9, warmup_seconds=.25,
                             batch_seconds=.1, batch_min_operations=3, discard_samples=2))
for i in (41, 43, 45, 47):
    print(f"{root.rsplit('-',1)[-1]} {engine} row{i} nl={rows[i]['case']['newline']!r} min={rows[i]['min_seconds']*1000:.1f}ms")
