#!/usr/bin/env bash
# G17 investigations (amendment 3), both pinned to CPU 13 behind the quiet gate.
#   PART=ladder  I1: runner categories at every src tree from WP0 to the final
#                candidate, in forward, reverse, reverse, forward rounds per engine
#   PART=order   I2: structural-order.txt steps, C0 (A) against the final
#                candidate (B), once per position in ABBA order per engine
# Every input comes from manifest-$PART.json, pinned in harness.sha256; the
# systemd unit pins the hashes of this script and of harness.sha256.
set -euo pipefail
REPO=/home/geoff/Projects/personal/aiogzip
BENCH=$REPO/.cache/wp10-bench
PART=${PART:?set PART to ladder or order}
case "$PART" in ladder|order) ;; *) echo "unknown PART $PART"; exit 1 ;; esac
PY=$REPO/.venv/bin/python
UV=/home/geoff/.local/bin/uv
CPU=13
ROOTS=/tmp/aiogzip-g17-inv
RUNNER=$ROOTS/runner
cd "$BENCH"
sha256sum --check --strict --quiet harness.sha256 || { echo "harness hash mismatch"; exit 1; }
MANIFEST=$BENCH/manifest-$PART.json
field() { "$PY" -c 'import json,sys; v=json.load(open(sys.argv[1]))
for k in sys.argv[2:]: v=v[int(k)] if isinstance(v, list) else v[k]
print(" ".join(v) if isinstance(v, list) else v)' "$MANIFEST" "$@"; }
[ "$(field mode)" = "$PART" ] || { echo "manifest mode mismatch"; exit 1; }
RUNNER_SHA=$(field runner)
cd "$REPO"

OUT=$BENCH/investigation-$PART-$(date +%Y%m%d-%H%M%S)
mkdir -p "$OUT"
cp "$MANIFEST" "$OUT/manifest.json"

# Fresh worktrees at the exact pinned commits: the runner, then one per root.
if [ -e "$ROOTS" ]; then
  shopt -s nullglob
  for w in "$ROOTS"/*; do git worktree remove --force "$w"; done
  shopt -u nullglob
  rmdir "$ROOTS"
fi
git worktree prune
mkdir -p "$ROOTS"
declare -a SHAS NAMES
if [ "$PART" = ladder ]; then
  read -r -a SHAS <<< "$(field commits)"
  for i in "${!SHAS[@]}"; do NAMES[i]=$(printf '%02d' "$i"); done
else
  SHAS=("$(field a)" "$(field b)"); NAMES=(A B)
fi
git worktree add -q --detach "$RUNNER" "$RUNNER_SHA"
for i in "${!SHAS[@]}"; do
  git worktree add -q --detach "$ROOTS/${NAMES[i]}" "${SHAS[i]}"
done
for i in "${!SHAS[@]}" runner; do
  if [ "$i" = runner ]; then w=$RUNNER; sha=$RUNNER_SHA; else w=$ROOTS/${NAMES[i]}; sha=${SHAS[i]}; fi
  [ "$(git -C "$w" rev-parse HEAD)" = "$sha" ] || { echo "commit mismatch $w"; exit 1; }
  [ -z "$(git -C "$w" status --porcelain)" ] || { echo "dirty $w"; exit 1; }
done
[ "$(git rev-parse "$RUNNER_SHA:benchmarks")" = "$(field runner_benchmarks_tree)" ] || { echo "runner benchmarks tree mismatch"; exit 1; }
[ "$(git rev-parse "$RUNNER_SHA:scripts")" = "$(field runner_scripts_tree)" ] || { echo "runner scripts tree mismatch"; exit 1; }
[ "$(sha256sum < "$RUNNER/uv.lock" | cut -c1-64)" = "$(field uv_lock_sha256)" ] || { echo "runner uv.lock mismatch"; exit 1; }
[ "$(sha256sum < uv.lock | cut -c1-64)" = "$(field uv_lock_sha256)" ] || { echo "main uv.lock mismatch"; exit 1; }
"$UV" sync --locked --all-extras --check > "$OUT/uv-sync-check.log" 2>&1 || { echo "venv not in sync with uv.lock"; exit 1; }
[ "$("$PY" "$BENCH/envcheck.py" "$OUT/environment.json")" = "$(field env_fingerprint)" ] || { echo "environment fingerprint mismatch"; exit 1; }

if ! "$PY" "$BENCH/quiet_gate.py" gate > "$OUT/quiet-gate.log" 2>&1; then
  echo "deferred: see $OUT/quiet-gate.log"
  exit 0
fi

{
  date; uptime
  cat "$BENCH/harness.sha256"
  sha256sum "$BENCH/investigate.sh" "$BENCH/harness.sha256"
} > "$OUT/provenance.txt"

"$PY" "$BENCH/quiet_gate.py" monitor > "$OUT/foreign.log" 2>&1 &
MONITOR=$!
trap 'kill "$MONITOR" 2>/dev/null || true' EXIT

printf 'engine\tn\tside\tstep\tstart\tend\n' > "$OUT/captures.tsv"
record() {  # engine n side step start
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$1" "$2" "$3" "$4" "$5" "$(date +%s.%N)" >> "$OUT/captures.tsv"
}

if [ "$PART" = ladder ]; then
  CATEGORIES=$(field categories)
  last=$((${#SHAS[@]} - 1))
  for engine in stdlib zlib-ng; do
    round=0
    for direction in F R R F; do
      round=$((round+1))
      if [ "$direction" = F ]; then order=$(seq 0 "$last"); else order=$(seq "$last" -1 0); fi
      for i in $order; do
        name=${NAMES[i]}
        start=$(date +%s.%N)
        taskset -c "$CPU" "$PY" "$RUNNER/benchmarks/run_benchmarks.py" \
          --category "$CATEGORIES" --repeat 5 \
          --engine "$engine" --source-root "$ROOTS/$name" \
          --output "$OUT/$engine-r$round-$name.json" < /dev/null > "$OUT/$engine-r$round-$name.log" 2>&1 \
          && status=0 || status=$?
        record "$engine" "$round" "$name" runner "$start"
        if [ "$status" -ne 0 ]; then
          printf '%s\t%s\t%s\t%s\n' "$engine" "$round" "$name" "$status" >> "$OUT/failures.tsv"
          # An endpoint failure refuses the run, so stop at once.
          if [ "$i" -eq 0 ] || [ "$i" -eq "$last" ]; then echo "endpoint $name failed"; exit 1; fi
        fi
      done
      echo "$engine round $round ($direction) done $(date +%T)"
    done
  done
else
  mkdir -p "$OUT/structural"
  cp "$BENCH/structural-order.txt" "$OUT/structural/steps.txt"
  for engine in stdlib zlib-ng; do
    while IFS='|' read -r label engines script args; do
      if [ -z "$label" ] || [ "${label#\#}" != "$label" ]; then continue; fi
      case " $engines " in *" $engine "*) ;; *) continue ;; esac
      pos=0
      for side in A B B A; do
        pos=$((pos+1))
        engine_args=(--engine "$engine")
        [ "$script" = measure_b2_partial_read.py ] && engine_args=()
        start=$(date +%s.%N)
        # shellcheck disable=SC2086
        taskset -c "$CPU" "$PY" "$RUNNER/scripts/$script" \
          --source-root "$ROOTS/$side" "${engine_args[@]}" $args \
          --output "$OUT/structural/$label-$engine-$pos$side.json" \
          < /dev/null > "$OUT/structural/$label-$engine-$pos$side.log" 2>&1
        record "$engine" "$label-$pos" "$side" structural "$start"
        echo "$label $engine $pos$side done $(date +%T)"
      done
    done < "$BENCH/structural-order.txt"
  done
fi
sleep 6  # one more monitor sample after the last capture
echo "results in $OUT"
