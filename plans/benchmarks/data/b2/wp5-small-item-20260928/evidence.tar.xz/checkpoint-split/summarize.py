import hashlib
import json
from pathlib import Path
from statistics import median
p=Path(__file__).resolve().parent
caps={(n,s):json.loads((p/f'{n}-{s}.json').read_text()) for n in range(6) for s in 'ABC'}
rows=[]
for i in range(3):
 rounds=[]
 for n in range(6):
  v={s:min(b['seconds'] for b in caps[n,s]['rows'][i]['batches'][2:]) for s in 'ABC'}
  rounds.append(dict(round=n,seconds=v,b_over_a=v['B']/v['A'],c_over_a=v['C']/v['A'],b_minus_c_ms=(v['B']-v['C'])*1000))
 r=caps[0,'A']['rows'][i]
 rows.append(dict(fixture=r['fixture'],compress=r['compress'],rounds=rounds,median_b_over_a=median(x['b_over_a'] for x in rounds),median_c_over_a=median(x['c_over_a'] for x in rounds),median_b_minus_c_ms=median(x['b_minus_c_ms'] for x in rounds),counts={s:[caps[n,s]['rows'][i]['counts'] for n in range(6)] for s in 'ABC'}))
d=dict(rows=rows,sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(p.glob('*.json')) if f.name!='summary.json'},limitations='Exploratory, not qualification; six within-round ratios of retained min-of-five batch means. No host activity screen. C has replacement codec checkpoints; no production change.')
(p/'summary.json').write_text(json.dumps(d,indent=2))
for r in rows:
 print(r['fixture'],r['compress'],'B/A',round((r['median_b_over_a']-1)*100,2),'C/A',round((r['median_c_over_a']-1)*100,2),'B-C ms',round(r['median_b_minus_c_ms'],3),'B-C rounds',[round(x['b_minus_c_ms'],3) for x in r['rounds']])
