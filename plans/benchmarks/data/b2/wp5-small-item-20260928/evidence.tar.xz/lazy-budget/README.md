# Lazy codec-budget experiment — 2026-09-28

Rejected production experiment; exact patch retained in production.patch and its
SHA-256 in summary.json. The working source was held unchanged throughout timing,
then reverted. Only four additional empty-operation budget tests remain in the
working tree. 149 focused streaming/fairness tests and all-file prek pass.

B is clean f73ae8d, D is the explicitly dirty working source with the archived
patch. Four balanced BD/DB rounds, CPU13, copied Python3.14.2 environment, stdlib,
4MiB fixtures in 64-byte items; same warmup/batch/discard policy as the earlier
checkpoint split. Timing and checkpoint instrumentation were separate. This is
exploratory evidence with no foreign-CPU screen, not qualification.

The patch deferred loading four shared budget counters until the first non-DONE
codec result and skipped writeback for empty operations. Claude found no
correctness issue; pointed out the added per-step branch and need for large-item
controls before any adoption.

| Case | D/B median elapsed-time change | Range over rounds |
| --- | ---: | ---: |
| text compression | -0.61% | -1.75% to +1.34% |
| random compression | 0.00% | -0.76% to +0.15% |
| random decompression | +1.14% | -0.67% to +1.75% |

No demonstrated benefit justifies retaining the production complexity. These
results do not prove a zero effect; drift limits resolution. No larger-item
qualification was attempted after rejecting this candidate. Fairness ceiling
remains 256; no new windows scheduled; G08 remains open.
