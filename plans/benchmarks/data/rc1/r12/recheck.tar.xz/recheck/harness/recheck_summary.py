"""Validate and summarize one recheck.sh run.

    recheck_summary.py RECHECK_DIR

Refuses the run (exit 1) when a result is missing, mislabeled, imported from
the wrong source, ran a different attrib.py, used other calls/batches, has a
non-finite or non-positive median, or when foreign-CPU samples do not cover a
process continuously or exceed 2.5 cores during it (R12's rules).

Reports, per engine and fixture: each variant's median and minimum over the
six rounds of the per-process medians, and the within-round differences
full - b2, fix - b2 and fix - full as the median over rounds with the range,
each also as a percentage of its reference. The verdict uses R12's registered
statistic, 100 * (min(fix) / min(b2) - 1) over the per-process medians, against
the 5%/10% policy; the paired figures are supporting evidence.
"""

import hashlib
import json
import math
import statistics
import sys
from pathlib import Path

BENCH = Path(__file__).resolve().parent
SAMPLE, SLACK, LIMIT = 5.0, 1.0, 2.5
A_SHA = "962bfe479a36d57df28f26cc4395c3f79eb96bc7"
B_SHA = "dd70af4f42bb608687aa5bf03032f6b13c3dcf21"
C_SHA = "f7c03c01f604ade992c151d7435b068e3a03078b"
VARIANTS = ("b2", "full", "fix")
ENGINES = ("stdlib", "zlib-ng")
FIXTURES = ("incompressible", "compressible")
READS = {"incompressible": 6, "compressible": 2}
ROUNDS = range(1, 7)
ORDERS = (
    ("b2", "full", "fix"),
    ("full", "fix", "b2"),
    ("fix", "b2", "full"),
    ("b2", "fix", "full"),
    ("fix", "full", "b2"),
    ("full", "b2", "fix"),
)


def fail(message):
    print(f"REFUSED: {message}")
    sys.exit(1)


def main():
    out = Path(sys.argv[1])
    provenance = (out / "provenance.txt").read_text().splitlines()
    shas = dict(line.split(" ", 1) for line in provenance[:3])
    if (shas.get("a"), shas.get("b"), shas.get("c")) != (A_SHA, B_SHA, C_SHA):
        fail(f"provenance commits {shas}")
    pinned = hashlib.sha256((BENCH / "recheck_verify.py").read_bytes()).hexdigest()
    roots = {
        "b2": "/tmp/aiogzip-r12x-b2",
        "full": "/tmp/aiogzip-r12x-cand",
        "fix": "/tmp/aiogzip-r12x-fix",
    }

    medians, fixtures_sha = {}, {}
    for r in ROUNDS:
        for engine in ENGINES:
            for fixture in FIXTURES:
                for variant in VARIANTS:
                    p = out / f"{r}-{engine}-{fixture}-{variant}.json"
                    if not p.exists():
                        fail(f"missing {p.name}")
                    rec = json.loads(p.read_text())
                    root = roots[variant]
                    checks = {
                        "label": (rec["variant"], rec["fixture"], rec["engine"])
                        == (variant, fixture, engine),
                        "root": rec["source_root"] == root
                        and rec["aiogzip_file"].startswith(root + "/src/"),
                        "script": rec["script_sha256"] == pinned,
                        "shape": (rec["calls"], rec["batches"]) == (200, 5),
                        "engine": rec["engine_info"]["decompression"]
                        == ("zlib-ng" if engine == "zlib-ng" else "stdlib-zlib"),
                        "median": math.isfinite(rec["median_s"])
                        and rec["median_s"] > 0,
                    }
                    bad = [k for k, ok in checks.items() if not ok]
                    if bad:
                        fail(f"{p.name}: {bad}")
                    if (
                        fixtures_sha.setdefault(fixture, rec["fixture_sha256"])
                        != rec["fixture_sha256"]
                    ):
                        fail(f"{p.name}: fixture differs")
                    medians[(r, engine, fixture, variant)] = rec["median_s"] * 1e6

    samples = []
    for line in (out / "foreign.log").read_text().splitlines():
        parts = line.split()
        if len(parts) == 2:
            t, c = float(parts[0]), float(parts[1])
            if not (math.isfinite(t) and math.isfinite(c)):
                fail(f"non-finite foreign-CPU sample {line!r}")
            samples.append((t, c))
    rows = (out / "runs.tsv").read_text().splitlines()[1:]
    order = [
        (str(r), engine, fixture, variant)
        for r in ROUNDS
        for engine in ENGINES
        for fixture in FIXTURES
        for variant in ORDERS[r - 1]
    ]
    if [tuple(row.split("\t")[:4]) for row in rows] != order:
        fail("runs.tsv does not list each process once, in the prescribed order")
    peak = 0.0
    for row in rows:
        r, engine, fixture, variant, start, end = row.split("\t")
        start, end = float(start), float(end)
        if not (math.isfinite(start) and math.isfinite(end) and start < end):
            fail(f"{row!r} has an invalid interval")
        hits = [(t, c) for t, c in samples if start < t and t - SAMPLE < end]
        times = [t for t, _ in hits]
        gaps = [b - a for a, b in zip(times, times[1:], strict=False)]
        if (
            not hits
            or times[0] - SAMPLE > start + SLACK
            or times[-1] < end
            or any(g > SAMPLE + SLACK for g in gaps)
        ):
            fail(f"{row!r} not continuously covered by foreign-CPU samples")
        top = max(c for _, c in hits)
        if top > LIMIT:
            fail(f"{row!r} ran with foreign CPU {top:.2f}")
        peak = max(peak, top)
    print(f"{out.name}: {len(rows)} processes valid; peak foreign CPU {peak:.2f} cores")

    for engine in ENGINES:
        for fixture in FIXTURES:
            print(
                f"\n== {engine} / {fixture} ({READS[fixture]} settled reads per call)"
            )
            for v in VARIANTS:
                xs = [medians[(r, engine, fixture, v)] for r in ROUNDS]
                print(
                    f"  {v:9} median {statistics.median(xs):8.1f} us  min {min(xs):8.1f} us"
                )
            for label, (x, y) in {
                "full - b2": ("full", "b2"),
                "fix - b2": ("fix", "b2"),
                "fix - full": ("fix", "full"),
            }.items():
                ds = [
                    medians[(r, engine, fixture, x)] - medians[(r, engine, fixture, y)]
                    for r in ROUNDS
                ]
                pct = [
                    d / medians[(r, engine, fixture, y)] * 100
                    for d, r in zip(ds, ROUNDS, strict=True)
                ]
                print(
                    f"  {label:12} {statistics.median(ds):+7.1f} us"
                    f" ({statistics.median(pct):+5.1f}%)"
                    f"  range [{min(ds):+.1f}, {max(ds):+.1f}]"
                )

            # R12's registered statistic: each side's minimum of the
            # per-process medians, judged by the 5%/10% policy.
            lows = {
                v: min(medians[(r, engine, fixture, v)] for r in ROUNDS)
                for v in VARIANTS
            }
            for x in ("full", "fix"):
                delta = 100 * (lows[x] / lows["b2"] - 1)
                verdict = (
                    "> 10%: blocks by default"
                    if delta > 10
                    else "> 5%: needs a disposition"
                    if delta > 5
                    else "within 5%"
                )
                print(f"  R12 min-of-medians {x} vs b2: {delta:+.2f}%  ({verdict})")


if __name__ == "__main__":
    main()
