"""Validate the WP7 window and compare C0 (A) with the candidate (B).

Refuses partial, failed, mixed or mislabeled captures. Primary statistic: the
per-benchmark minimum of the four capture medians on each side (CLAUDE.md
method A). Also prints the four adjacent A/B pair deltas, so a minimum delta
above 5% can be judged against interleaved consistency, and marks captures
during which foreign CPU exceeded 2.5 cores.

    summarize.py RESULTS_DIR CANDIDATE_SHA
"""

import json
import sys
from pathlib import Path

C0_SHA = "b074bdc77e45e9033769fb96a999e98e8931c24b"
CATEGORIES = ["io", "micro", "text_origin"]
ORDER = ["A", "B", "B", "A", "A", "B", "B", "A"]
PAIRS = [(1, 2), (4, 3), (5, 6), (8, 7)]  # (A capture, adjacent B capture)
CEILING = 2.5
SAMPLE = 5.0
SLACK = 1.0  # sampling overhead per 5 s interval


def fail(message):
    sys.exit(f"INVALID: {message}")


def load(out, engine, n, side, candidate):
    path = out / f"{engine}-{n}-{side}.json"
    if not path.is_file():
        fail(f"missing {path.name}")
    data = json.loads(path.read_text())
    expected = C0_SHA if side == "A" else candidate
    checks = {
        "status": (data.get("status"), "complete"),
        "categories": (data.get("categories"), CATEGORIES),
        "completed": (data.get("completed_categories"), CATEGORIES),
        "repeat": (data.get("repeat"), 5),
        "target_commit": (data["source"].get("target_commit"), expected),
        "target_dirty": (data["source"].get("target_dirty"), False),
        "runner_commit": (data["environment"].get("runner_commit"), candidate),
        "requested_engine": (data["environment"].get("requested_engine"), engine),
    }
    for key, (actual, wanted) in checks.items():
        if actual != wanted:
            fail(f"{path.name}: {key} is {actual!r}, expected {wanted!r}")
    active = data["environment"]["active_engines"]["decompression"]
    if active != ("zlib-ng" if engine == "zlib-ng" else "stdlib-zlib"):
        fail(f"{path.name}: decompression engine {active!r}")
    return {(r["category"], r["name"]): r["duration"] for r in data["results"]}


def contaminated(out):
    """Peak foreign CPU over each capture, from samples that fully cover it.

    A sample at time t covers the interval (t - 5, t]. It overlaps a capture
    [start, end] when start < t and t - 5 < end. Coverage must be continuous
    from before the start to after the end.
    """
    samples = []
    for line in (out / "foreign.log").read_text().splitlines():
        parts = line.split()
        if len(parts) == 2:
            samples.append((float(parts[0]), float(parts[1])))
    windows = {}
    for row in (out / "captures.tsv").read_text().splitlines()[1:]:
        engine, n, side, start, end = row.split("\t")
        start, end = float(start), float(end)
        hits = [(t, c) for t, c in samples if start < t and t - SAMPLE < end]
        if not hits:
            fail(f"{engine} capture {n} has no foreign-CPU samples")
        times = [t for t, _ in hits]
        gaps = [b - a for a, b in zip(times, times[1:], strict=False)]
        if (
            times[0] - SAMPLE > start + SLACK
            or times[-1] < end
            or any(gap > SAMPLE + SLACK for gap in gaps)
        ):
            fail(f"{engine} capture {n} is not continuously covered by samples")
        windows[(engine, int(n))] = max(c for _, c in hits)
    return windows


def main():
    out, candidate = Path(sys.argv[1]), sys.argv[2]
    windows = contaminated(out)
    for engine in ("stdlib", "zlib-ng"):
        rows = {}
        for n, side in enumerate(ORDER, start=1):
            rows[n] = load(out, engine, n, side, candidate)
        names = set(rows[1])
        for n in rows:
            if set(rows[n]) != names:
                fail(f"{engine} capture {n} has a different benchmark set")
        print(f"\n== {engine}")
        peaks = {n: windows[(engine, n)] for n in rows}
        print(
            "peak foreign cores per capture: "
            + " ".join(f"{n}:{peaks[n]:.2f}" for n in rows)
        )
        dirty = [n for n in rows if peaks[n] > CEILING]
        if dirty:
            # One-off protocol: every capture must be clean.
            fail(
                f"{engine} captures {dirty} ran with foreign CPU above {CEILING} cores"
            )
        flagged = 0
        for key in sorted(names):
            a = [rows[n][key] for n, s in enumerate(ORDER, 1) if s == "A"]
            b = [rows[n][key] for n, s in enumerate(ORDER, 1) if s == "B"]
            delta = (min(b) / min(a) - 1) * 100
            pairs = [(rows[nb][key] / rows[na][key] - 1) * 100 for na, nb in PAIRS]
            mark = "  <-- >5%" if delta > 5 else ""
            flagged += delta > 5
            print(
                f"{key[0]:12} {delta:+7.2f}%  pairs "
                + " ".join(f"{p:+6.1f}" for p in pairs)
                + f"  A={min(a) * 1000:9.3f}ms  {key[1]}{mark}"
            )
        print(f"{flagged} benchmark(s) more than 5% slower by minimum")


if __name__ == "__main__":
    main()
