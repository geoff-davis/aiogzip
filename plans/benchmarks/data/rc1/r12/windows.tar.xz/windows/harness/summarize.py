"""Validate and summarize the R12 windows.

    summarize.py window DIR   validate a window against its window.json, then
                              compare

There is no preflight. A window is refused when a capture is missing,
failed or mislabeled, from the wrong commit, runner or engine, or not clean;
when a runner capture's row set is not exactly the pinned inventory in
runner-rows.json (G17's frozen runner rows plus the nine inspection rows);
when, per engine, the eight runner captures do not all have one identical row
set, or the write captures or rc1_paths.py captures do not all have identical
fixtures and result names; when rc1_paths.py's hash differs from the pinned
one; or when foreign CPU exceeds 2.5 cores or its samples do not cover every
step. The primary statistic is the per-benchmark minimum of the four capture
medians on each side (CLAUDE.md method A), for the runner categories, the
write sizes and the rc1_paths.py rows alike, with the four adjacent A/B pair
deltas.
"""

import hashlib
import json
import math
import sys
from pathlib import Path

ORDER = ["A", "B", "B", "A", "A", "B", "B", "A"]
PAIRS = [(1, 2), (4, 3), (5, 6), (8, 7)]  # (A capture, adjacent B capture)
WRITE_SIZES = [10, 100, 1024, 4096, 16384, 65536, 262144]
WRITE_METHODS = ["write", "writelines", "batch-65536", "batch-262144"]
PATH_ROWS = [
    "open/close x200",
    "open + seek_end drain x20",
    "open + peek + seek_end x200",
    "text writelines empty runs x20",
]
ENGINES = ("stdlib", "zlib-ng")
STEPS = ("runner", "writes", "paths")
CEILING = 2.5
SAMPLE = 5.0
SLACK = 1.0  # sampling overhead per 5 s interval
BENCH = Path(__file__).resolve().parent


def fail(message):
    sys.exit(f"INVALID: {message}")


def check(name, checks):
    for key, (actual, wanted) in checks.items():
        if actual != wanted:
            fail(f"{name}: {key} is {actual!r}, expected {wanted!r}")


def positive(name, value):
    """A finite, strictly positive measurement."""
    if not finite(value) or value <= 0:
        fail(f"{name} is {value!r}, expected a finite positive number")
    return value


def finite(value):
    return number(value) and math.isfinite(value)


def decompression(engine):
    return "zlib-ng" if engine == "zlib-ng" else "stdlib-zlib"


def read_json(path):
    if not path.is_file():
        fail(f"missing {path}")
    return json.loads(path.read_text())


def runner_rows(path, *, sha, runner, engine, categories, repeat):
    data = read_json(path)
    check(
        path.name,
        {
            "status": (data.get("status"), "complete"),
            "categories": (data.get("categories"), categories),
            "completed": (data.get("completed_categories"), categories),
            "repeat": (data.get("repeat"), repeat),
            # run_benchmarks.py records these only when regressions is selected
            "regression_profile": (
                data.get("regression_profile"),
                "quick" if "regressions" in categories else None,
            ),
            "regression_mode": (
                data.get("regression_mode"),
                "throughput" if "regressions" in categories else None,
            ),
            "target_commit": (data["source"].get("target_commit"), sha),
            "target_dirty": (data["source"].get("target_dirty"), False),
            "runner_commit": (data["environment"].get("runner_commit"), runner),
            "requested_engine": (data["environment"].get("requested_engine"), engine),
            "decompression": (
                data["environment"]["active_engines"]["decompression"],
                decompression(engine),
            ),
        },
    )
    rows = {}
    memory = {}
    for r in data["results"]:
        key = (r["category"], r["name"])
        if key in rows:
            fail(f"{path.name}: duplicate row {key}")
        rows[key] = positive(f"{path.name}: {key} duration", r.get("duration"))
        if r["category"] == "memory":
            # bench_memory records the increase formatted, e.g. "12.3".
            increase = (r.get("metrics") or {}).get("memory_increase_mb")
            try:
                increase = float(increase)
            except (TypeError, ValueError):
                fail(f"{path.name}: {key} memory_increase_mb is {increase!r}")
            if not finite(increase):
                fail(f"{path.name}: {key} memory_increase_mb is {increase!r}")
            memory[r["name"]] = increase
    return rows, memory


def write_rows(path, *, sha, runner, engine, repeat):
    data = read_json(path)
    config = data["configuration"]
    check(
        path.name,
        {
            "categories": (config.get("categories"), ["writes"]),
            "write_sizes": (config.get("write_sizes"), WRITE_SIZES),
            "repeat": (config.get("repeat"), repeat),
            "commit": (data["source"].get("commit"), sha),
            "dirty": (data["source"].get("dirty_tracked"), False),
            "runner_commit": (data["environment"].get("runner_commit"), runner),
            "requested_engine": (data["source"].get("requested_engine"), engine),
        },
    )
    expected = {
        f"{method} {size}B records" for size in WRITE_SIZES for method in WRITE_METHODS
    }
    results = data["results"]
    names = [r["name"] for r in results]
    if len(names) != len(set(names)) or set(names) != expected:
        fail(f"{path.name}: unexpected write result set")
    for r in results:
        if r.get("status") != "ok" or r.get("sample_count") != repeat:
            fail(f"{path.name}: {r['name']} status {r.get('status')!r}")
    fixtures = data.get("fixtures")
    if not fixtures:
        fail(f"{path.name}: no fixture identities")
    medians = {
        ("writes", r["name"]): positive(
            f"{path.name}: {r['name']} median", r.get("median_seconds")
        )
        for r in results
    }
    return medians, fixtures


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def path_rows(path, *, sha, engine, repeat):
    data = read_json(path)
    script = (BENCH / "rc1_paths.py").read_bytes()
    check(
        path.name,
        {
            "script_sha256": (data.get("script_sha256"), hashlib.sha256(script).hexdigest()),
            "commit": (data["source"].get("commit"), sha),
            "dirty": (data["source"].get("dirty"), False),
            "requested_engine": (data["engine"].get("requested"), engine),
            "decompression": (
                data["engine"]["active"].get("decompression"),
                decompression(engine),
            ),
            "repeat": (data.get("repeat"), repeat),
            "names": ([r.get("name") for r in data["results"]], PATH_ROWS),
        },
    )
    for r in data["results"]:
        if r.get("status") != "ok" or r.get("sample_count") != repeat:
            fail(f"{path.name}: {r['name']} status {r.get('status')!r}")
        if len(r.get("samples") or []) != repeat:
            fail(f"{path.name}: {r['name']} has {len(r.get('samples') or [])} samples")
    medians = {
        ("rc1_paths", r["name"]): positive(
            f"{path.name}: {r['name']} median", r.get("median_seconds")
        )
        for r in data["results"]
    }
    return medians, data["fixtures"]


def coverage(out):
    """Peak foreign CPU over each capture, from samples that fully cover it.

    A sample at time t covers the interval (t - 5, t]. It overlaps a capture
    [start, end] when start < t and t - 5 < end. Coverage must be continuous
    from before the start to after the end.
    """
    samples = []
    for line in (out / "foreign.log").read_text().splitlines():
        parts = line.split()
        if len(parts) == 2:
            samples.append((float(parts[0]), float(parts[1])))
    peaks = {}
    for row in (out / "captures.tsv").read_text().splitlines()[1:]:
        engine, n, side, step, start, end = row.split("\t")
        start, end = float(start), float(end)
        hits = [(t, c) for t, c in samples if start < t and t - SAMPLE < end]
        if not hits:
            fail(f"{engine} {n} {side} {step} has no foreign-CPU samples")
        times = [t for t, _ in hits]
        gaps = [b - a for a, b in zip(times, times[1:], strict=False)]
        if (
            times[0] - SAMPLE > start + SLACK
            or times[-1] < end
            or any(gap > SAMPLE + SLACK for gap in gaps)
        ):
            fail(f"{engine} {n} {side} {step} is not continuously covered by samples")
        key = (engine, n, side, step)
        if key in peaks:
            fail(f"duplicate capture row {key}")
        peaks[key] = max(c for _, c in hits)
    return peaks


def window(out):
    win = read_json(out / "window.json")
    shas = {"A": win["a"], "B": win["b"]}
    categories = win["categories"].split(",")
    inventory = read_json(BENCH / "runner-rows.json")["runner"]
    peaks = coverage(out)
    print(
        f"mode {win['mode']}: A {win['a_role']} {shas['A'][:12]}  "
        f"B {win['b_role']} {shas['B'][:12]}  runner {win['runner'][:12]}"
    )
    for engine in ENGINES:
        rows, memory = {}, {}
        runner_sets, write_fixtures, path_fixtures = set(), [], []
        for n, side in enumerate(ORDER, start=1):
            runner, memory[n] = runner_rows(
                out / f"{engine}-{n}-{side}.json",
                sha=shas[side],
                runner=win["runner"],
                engine=engine,
                categories=categories,
                repeat=5,
            )
            if sorted(f"{c}::{name}" for c, name in runner) != inventory:
                fail(f"{engine} capture {n}: runner row set differs from runner-rows.json")
            runner_sets.add(frozenset(runner))
            writes, fixtures = write_rows(
                out / f"{engine}-{n}-{side}-writes.json",
                sha=shas[side],
                runner=win["runner"],
                engine=engine,
                repeat=5,
            )
            write_fixtures.append(fixtures)
            paths, fixtures = path_rows(
                out / f"{engine}-{n}-{side}-paths.json",
                sha=shas[side],
                engine=engine,
                repeat=5,
            )
            path_fixtures.append(fixtures)
            rows[n] = {**runner, **writes, **paths}
            for step in STEPS:
                peak = peaks.get((engine, str(n), side, step))
                if peak is None:
                    fail(f"{engine} capture {n} {step} has no capture boundaries")
                if peak > CEILING:
                    fail(f"{engine} capture {n} {step} ran with foreign CPU {peak:.2f}")
        if len(runner_sets) != 1:
            fail(f"{engine}: the runner captures' row sets differ")
        if any(f != write_fixtures[0] for f in write_fixtures):
            fail(f"{engine}: the write captures' fixtures differ")
        if any(f != path_fixtures[0] for f in path_fixtures):
            fail(f"{engine}: the rc1_paths captures' fixtures differ")
        print(f"\n== {engine}")
        print(
            "peak foreign cores per capture (runner/writes/paths): "
            + " ".join(
                f"{n}:"
                + "/".join(f"{peaks[(engine, str(n), s, step)]:.2f}" for step in STEPS)
                for n, s in enumerate(ORDER, start=1)
            )
        )
        print(
            "memory_increase_mb per capture: "
            + " ".join(f"{n}{ORDER[n - 1]}:{memory[n]}" for n in memory)
        )
        flagged, worst = 0, 0.0
        for key in sorted(rows[1]):
            a = [rows[n][key] for n, s in enumerate(ORDER, 1) if s == "A"]
            b = [rows[n][key] for n, s in enumerate(ORDER, 1) if s == "B"]
            delta = (min(b) / min(a) - 1) * 100
            pairs = [(rows[nb][key] / rows[na][key] - 1) * 100 for na, nb in PAIRS]
            mark = "  <-- >5%" if delta > 5 else ""
            flagged += delta > 5
            worst = max(worst, abs(delta))
            print(
                f"{key[0]:12} {delta:+7.2f}%  pairs "
                + " ".join(f"{p:+6.1f}" for p in pairs)
                + f"  A={min(a) * 1000:9.3f}ms  {key[1]}{mark}"
            )
        print(f"{flagged} benchmark(s) more than 5% slower by minimum")
        print(f"largest absolute minimum delta {worst:.2f}%")


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] != "window":
        sys.exit(__doc__)
    window(Path(sys.argv[2]))
