#!/usr/bin/env bash
# One timer attempt at the S06 windows. A window counts as attempted once its
# quiet gate has passed (run.sh writes provenance.txt only after the gate), so
# a deferred window is retried at the next attempt and a gated one never is.
# The aa control runs only after ab has passed its gate, so it follows ab.
set -euo pipefail
BENCH=/home/geoff/Projects/personal/aiogzip/.cache/rc2-bench
cd "$BENCH"
gated() { compgen -G "$BENCH/results-$1-*/provenance.txt" > /dev/null; }
for MODE in ab aa; do
  if gated "$MODE"; then
    echo "$MODE: already gated, skipping"
    continue
  fi
  MODE=$MODE /usr/bin/bash "$BENCH/run.sh"
  if ! gated "$MODE"; then
    echo "$MODE: deferred; later windows wait for the next attempt"
    exit 0
  fi
done
echo "both windows gated; nothing left to attempt"
